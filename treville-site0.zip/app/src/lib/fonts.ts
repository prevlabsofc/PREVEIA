import localFont from "next/font/local";

export const display = localFont({
  variable: "--font-display",
  display: "swap",
  fallback: ["Georgia", "Times New Roman", "serif"],
  src: [
    { path: "../fonts/newsreader-latin-300-normal.woff2", weight: "300", style: "normal" },
    { path: "../fonts/newsreader-latin-300-italic.woff2", weight: "300", style: "italic" },
    { path: "../fonts/newsreader-latin-ext-300-normal.woff2", weight: "300", style: "normal" },
    { path: "../fonts/newsreader-latin-ext-300-italic.woff2", weight: "300", style: "italic" },
  ],
});

export const body = localFont({
  variable: "--font-body",
  display: "swap",
  fallback: ["Segoe UI", "system-ui", "-apple-system", "sans-serif"],
  src: [
    { path: "../fonts/manrope-latin-400-normal.woff2", weight: "400", style: "normal" },
    { path: "../fonts/manrope-latin-500-normal.woff2", weight: "500", style: "normal" },
    { path: "../fonts/manrope-latin-600-normal.woff2", weight: "600", style: "normal" },
  ],
});

export const brand = localFont({
  variable: "--font-brand",
  display: "swap",
  fallback: ["Trajan Pro", "Georgia", "serif"],
  src: [{ path: "../fonts/cinzel-latin-500-normal.woff2", weight: "500", style: "normal" }],
});
