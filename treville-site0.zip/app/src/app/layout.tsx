import type { Metadata, Viewport } from "next";
import { SmoothScroll } from "@/components/SmoothScroll";
import { GLMount } from "@/components/three/GLMount";
import { Interactions } from "@/components/Interactions";
import { body, brand, display } from "@/lib/fonts";
import "./globals.css";

const DESC =
  "Estratégia, tecnologia e posicionamento para advogados e escritórios de advocacia que desejam construir uma reputação à altura da sua excelência.";

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000"),
  title: "TRÉVILLE",
  description: DESC,
  openGraph: {
    title: "TRÉVILLE · Autoridade não se improvisa.",
    description: DESC,
    images: [{ url: "/og.jpg", width: 1200, height: 630, alt: "TRÉVILLE" }],
    locale: "pt_BR",
    type: "website",
  },
  twitter: { card: "summary_large_image", images: ["/og.jpg"] },
};

export const viewport: Viewport = {
  themeColor: "#070605",
  colorScheme: "dark",
  viewportFit: "cover",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR" suppressHydrationWarning className={`${display.variable} ${body.variable} ${brand.variable}`}>
      <head>
        {/* segunda visita na mesma sessão: abertura mais curta */}
        <script
          dangerouslySetInnerHTML={{
            __html:
              "try{if(sessionStorage.getItem('tv-intro'))document.documentElement.classList.add('intro-fast');sessionStorage.setItem('tv-intro','1')}catch(e){}",
          }}
        />
      </head>
      <body>
        <div className="intro-curtain" aria-hidden="true">
          <i />
          <i />
        </div>
        <a className="skip-link" href="#conteudo">
          Pular para o conteúdo
        </a>
        <SmoothScroll>
          {children}
          <GLMount />
          <Interactions />
        </SmoothScroll>
      </body>
    </html>
  );
}
