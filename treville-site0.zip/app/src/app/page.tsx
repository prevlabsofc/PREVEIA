import { Footer } from "@/components/Footer";
import { Header } from "@/components/Header";
import { Contato } from "@/components/sections/Contato";
import { Filosofia } from "@/components/sections/Filosofia";
import { Hero } from "@/components/sections/Hero";
import { Pilares } from "@/components/sections/Pilares";
import { Socios } from "@/components/sections/Socios";

export default function Home() {
  return (
    <>
      <Header />
      <main id="conteudo">
        <Hero />
        <Filosofia />
        <Pilares />
        <Socios />
        <Contato />
      </main>
      <Footer />
    </>
  );
}
