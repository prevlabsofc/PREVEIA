import Image from "next/image";
import { LINKS } from "@/content/links";
import { Instagram, LinkedIn, WhatsApp } from "./icons";

export function Footer() {
  return (
    <footer className="site-footer">
      <div className="wrap">
        <a className="brand" href="#inicio" aria-label="TRÉVILLE, voltar ao início">
          <Image src="/images/treville-symbol.webp" alt="" width={40} height={34} />
          <span translate="no">TRÉVILLE</span>
        </a>
        <div className="tag">
          <p>Estratégia, tecnologia e crescimento para o mercado jurídico.</p>
        </div>
        <div className="social">
          <a href={LINKS.instagram} target="_blank" rel="noopener noreferrer" aria-label="Instagram">
            <Instagram />
          </a>
          <a href={LINKS.linkedin} target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">
            <LinkedIn />
          </a>
          <a href={LINKS.whatsapp} target="_blank" rel="noopener noreferrer" aria-label="WhatsApp">
            <WhatsApp />
          </a>
        </div>
        <p className="legal">
          © 2026 <span translate="no">TRÉVILLE</span>. Todos os direitos reservados.
        </p>
      </div>
    </footer>
  );
}
