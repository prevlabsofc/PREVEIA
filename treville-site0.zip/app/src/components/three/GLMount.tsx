"use client";

import dynamic from "next/dynamic";

const GLCanvas = dynamic(() => import("./GLCanvas"), { ssr: false });

export function GLMount() {
  return <GLCanvas />;
}
