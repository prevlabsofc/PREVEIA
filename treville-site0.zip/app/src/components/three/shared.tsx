"use client";

import { Environment, Lightformer, useGLTF } from "@react-three/drei";
import { useMemo } from "react";
import {
  AdditiveBlending,
  Box3,
  CanvasTexture,
  Group,
  Mesh,
  SRGBColorSpace,
  Vector3,
  type MeshStandardMaterial,
  type Object3D,
} from "three";

export const DRACO = "/draco/";
export const SYMBOL_URL = "/models/treville-symbol.glb";

/** Ambiente de estúdio gerado na hora (sem baixar HDR de fora). Luz quente, dourada. */
export function GoldStudio({ intensity = 1 }: { intensity?: number }) {
  return (
    <Environment resolution={256} frames={1} environmentIntensity={intensity}>
      <Lightformer form="rect" intensity={5} color="#ffe2b0" position={[2.5, 3, 2]} scale={[3, 2, 1]} target={[0, 0, 0]} />
      <Lightformer form="rect" intensity={2.2} color="#ffd38a" position={[-3, 1, 1.5]} scale={[1, 4, 1]} target={[0, 0, 0]} />
      <Lightformer form="rect" intensity={1.5} color="#ffe7c2" position={[-0.5, 1.2, 4]} scale={[5, 2.2, 1]} target={[0, 0, 0]} />
      <Lightformer form="rect" intensity={0.9} color="#ffcf80" position={[0, -1.5, 3]} scale={[4, 1, 1]} target={[0, 0.3, 0]} />
      <Lightformer form="ring" intensity={2} color="#f1d894" position={[1.5, -1, -3]} scale={2} target={[0, 0, 0]} />
      <Lightformer form="rect" intensity={0.6} color="#8fa6c8" position={[-2, 2, -3]} scale={[2, 2, 1]} target={[0, 0, 0]} />
    </Environment>
  );
}

/** Mesmo ouro claro e polido em todos os modelos. */
export function goldify(root: Object3D) {
  root.traverse((o) => {
    const m = o as Mesh;
    if (!m.isMesh) return;
    const mats = (Array.isArray(m.material) ? m.material : [m.material]) as MeshStandardMaterial[];
    mats.forEach((mat) => {
      if (mat.name === "Treville_Gold_Dark") return;
      mat.color.setRGB(0.93, 0.6, 0.19);
      mat.metalness = 1;
      mat.roughness = 0.17;
      mat.envMapIntensity = 1.05;
    });
  });
}

/**
 * Carrega um GLB e devolve uma cópia normalizada:
 * centralizada em X/Z, base em y=0 e altura = 1.
 */
export function useNormalizedModel(url: string, opts: { baseAtZero?: boolean; fit?: "height" | "max" } = {}) {
  const { scene } = useGLTF(url, DRACO);
  return useMemo(() => {
    const root = scene.clone(true);
    root.traverse((o: Object3D) => {
      const m = o as Mesh;
      if (m.isMesh) {
        m.castShadow = false;
        m.receiveShadow = false;
        // material próprio por instância (o cache do GLTF é compartilhado entre as cenas)
        m.material = Array.isArray(m.material) ? m.material.map((x) => x.clone()) : m.material.clone();
      }
    });
    const box = new Box3().setFromObject(root);
    const size = box.getSize(new Vector3());
    const center = box.getCenter(new Vector3());
    const s = 1 / (opts.fit === "max" ? Math.max(size.x, size.y, size.z) : size.y);
    const g = new Group();
    root.position.set(-center.x, -center.y, -center.z);
    const inner = new Group();
    inner.add(root);
    inner.scale.setScalar(s);
    if (opts.baseAtZero) inner.position.y = (size.y * s) / 2;
    g.add(inner);
    return { object: g, width: size.x * s, height: size.y * s, depth: size.z * s };
  }, [scene, opts.baseAtZero, opts.fit]);
}

let flareTex: CanvasTexture | null = null;
/** Textura radial para o brilho na ponta da flor-de-lis. */
export function useFlareTexture() {
  return useMemo(() => {
    if (flareTex) return flareTex;
    const c = document.createElement("canvas");
    c.width = c.height = 128;
    const g = c.getContext("2d")!;
    const r = g.createRadialGradient(64, 64, 0, 64, 64, 64);
    r.addColorStop(0, "rgba(255,250,235,1)");
    r.addColorStop(0.12, "rgba(255,230,170,0.9)");
    r.addColorStop(0.4, "rgba(232,180,90,0.25)");
    r.addColorStop(1, "rgba(232,180,90,0)");
    g.fillStyle = r;
    g.fillRect(0, 0, 128, 128);
    // raios finos
    g.globalCompositeOperation = "lighter";
    const ray = (w: number, h: number) => {
      const lg = g.createLinearGradient(64 - w / 2, 0, 64 + w / 2, 0);
      lg.addColorStop(0, "rgba(255,236,190,0)");
      lg.addColorStop(0.5, "rgba(255,236,190,0.55)");
      lg.addColorStop(1, "rgba(255,236,190,0)");
      g.fillStyle = lg;
      g.fillRect(64 - w / 2, 64 - h / 2, w, h);
    };
    ray(128, 2);
    g.save();
    g.translate(64, 64);
    g.rotate(Math.PI / 2);
    g.translate(-64, -64);
    ray(90, 1.5);
    g.restore();
    flareTex = new CanvasTexture(c);
    flareTex.colorSpace = SRGBColorSpace;
    return flareTex;
  }, []);
}

let beamTex: CanvasTexture | null = null;
/** Faixa de luz: brilho no centro do comprimento, sumindo nas pontas e nas bordas. */
export function useBeamTexture() {
  return useMemo(() => {
    if (beamTex) return beamTex;
    const c = document.createElement("canvas");
    c.width = 256;
    c.height = 32;
    const g = c.getContext("2d")!;
    const along = g.createLinearGradient(0, 0, 256, 0);
    along.addColorStop(0, "rgba(255,255,255,0)");
    along.addColorStop(0.3, "rgba(255,255,255,0.55)");
    along.addColorStop(0.62, "rgba(255,255,255,1)");
    along.addColorStop(1, "rgba(255,255,255,0)");
    g.fillStyle = along;
    g.fillRect(0, 0, 256, 32);
    g.globalCompositeOperation = "destination-in";
    const across = g.createLinearGradient(0, 0, 0, 32);
    across.addColorStop(0, "rgba(0,0,0,0)");
    across.addColorStop(0.5, "rgba(0,0,0,1)");
    across.addColorStop(1, "rgba(0,0,0,0)");
    g.fillStyle = across;
    g.fillRect(0, 0, 256, 32);
    beamTex = new CanvasTexture(c);
    beamTex.colorSpace = SRGBColorSpace;
    return beamTex;
  }, []);
}

export const flareMaterialProps = {
  transparent: true,
  depthWrite: false,
  blending: AdditiveBlending,
} as const;

useGLTF.preload(SYMBOL_URL, DRACO);
