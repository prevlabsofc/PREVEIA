"use client";

import { Canvas } from "@react-three/fiber";
import { Suspense, useEffect, useRef, useState } from "react";
import { ACESFilmicToneMapping, SRGBColorSpace } from "three";
import { PillarScene } from "./PillarScene";
import { store } from "./store";

/**
 * Canvas próprio para cada pilar: o liquid glass (refração de verdade) precisa
 * renderizar a cena de trás numa textura do tamanho certo, o que não funciona
 * dentro de uma janela do canvas compartilhado. Pausa quando sai da tela.
 */
export default function PillarView({
  url,
  slug,
  mode,
  trackRef,
}: {
  url: string;
  slug: string;
  mode: "card" | "focus";
  trackRef?: React.RefObject<HTMLElement | null>;
}) {
  const wrap = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(mode === "focus");
  const mobile = typeof window !== "undefined" && window.matchMedia("(max-width: 920px)").matches;

  useEffect(() => {
    if (mode === "focus") return;
    const el = wrap.current;
    if (!el) return;
    const io = new IntersectionObserver(([e]) => setInView(e.isIntersecting), { rootMargin: "100px 0px" });
    io.observe(el);
    return () => io.disconnect();
  }, [mode]);

  return (
    <div ref={wrap} className="gl-view-inner">
      <Canvas
        frameloop={inView ? "always" : "never"}
        dpr={[1, mobile ? 1.5 : 1.75]}
        gl={{ antialias: true, alpha: true, powerPreference: "high-performance" }}
        onCreated={({ gl }) => {
          gl.toneMapping = ACESFilmicToneMapping;
          gl.toneMappingExposure = 1.08;
          gl.outputColorSpace = SRGBColorSpace;
          gl.setClearColor(0x000000, 0);
        }}
        style={{ position: "absolute", inset: 0, pointerEvents: "none" }}
      >
        <Suspense fallback={null}>
          <PillarScene url={url} slug={slug} mode={mode} trackRef={trackRef} />
          <Ready k={`${mode}-${slug}`} />
        </Suspense>
      </Canvas>
    </div>
  );
}

function Ready({ k }: { k: string }) {
  useEffect(() => store.setReady(k), [k]);
  return null;
}
