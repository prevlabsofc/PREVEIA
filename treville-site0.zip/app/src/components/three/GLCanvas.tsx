"use client";

import { Canvas } from "@react-three/fiber";
import { View } from "@react-three/drei";
import { useEffect, useState } from "react";
import { ACESFilmicToneMapping, SRGBColorSpace } from "three";
import { pointer, store } from "./store";

function hasWebGL() {
  try {
    const c = document.createElement("canvas");
    return !!(c.getContext("webgl2") || c.getContext("webgl"));
  } catch {
    return false;
  }
}

/**
 * Um canvas WebGL só, fixo atrás de tudo que é clicável.
 * Cada modelo 3D do site é um <View> que desenha na sua própria janela.
 */
export default function GLCanvas() {
  const [ok, setOk] = useState(false);

  useEffect(() => {
    if (!hasWebGL()) return;
    setOk(true);
    store.set({ gl: true });

    const fine = window.matchMedia("(pointer: fine)").matches;
    const onMove = (e: PointerEvent) => {
      if (e.pointerType !== "mouse" && !fine) return;
      pointer.x = (e.clientX / window.innerWidth) * 2 - 1;
      pointer.y = -((e.clientY / window.innerHeight) * 2 - 1);
      pointer.active = true;
    };
    const onLeave = () => (pointer.active = false);
    window.addEventListener("pointermove", onMove, { passive: true });
    document.addEventListener("pointerleave", onLeave);
    return () => {
      window.removeEventListener("pointermove", onMove);
      document.removeEventListener("pointerleave", onLeave);
      store.set({ gl: false });
    };
  }, []);

  if (!ok) return null;

  const mobile = typeof window !== "undefined" && window.matchMedia("(max-width: 920px)").matches;

  return (
    <Canvas
      className="gl-canvas"
      dpr={[1, mobile ? 1.5 : 1.75]}
      gl={{ antialias: true, alpha: true, powerPreference: "high-performance" }}
      onCreated={({ gl }) => {
        gl.toneMapping = ACESFilmicToneMapping;
        gl.toneMappingExposure = 1.08;
        gl.outputColorSpace = SRGBColorSpace;
        gl.setClearColor(0x000000, 0);
      }}
      eventSource={typeof document !== "undefined" ? document.body : undefined}
      eventPrefix="client"
      style={{ position: "fixed", inset: 0, pointerEvents: "none" }}
    >
      <View.Port />
    </Canvas>
  );
}
