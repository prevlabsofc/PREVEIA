"use client";

import { Edges, Environment, Lightformer, PerspectiveCamera, RoundedBox } from "@react-three/drei";
import { flareMaterialProps, useFlareTexture, useNormalizedModel } from "./shared";
import { useFrame, useThree } from "@react-three/fiber";
import { useMemo, useRef, type ReactNode } from "react";
import { Color, ExtrudeGeometry, MathUtils, Path, Shape, type Group, type Mesh, type MeshStandardMaterial } from "three";
import { pointer, store } from "./store";

type Props = {
  /** mantido por compatibilidade; as esculturas são geradas aqui */
  url?: string;
  slug: string;
  /** elemento do card, para saber onde o cursor está em relação a ele */
  trackRef?: React.RefObject<HTMLElement | null>;
  /** "card": pequeno, reage ao hover/seleção. "focus": grande, no zoom. */
  mode: "card" | "focus";
};

/* ------------------------------------------------------------------
   Materiais
   - Ouro: metal sólido, opaco, polido e espelhado (sem transparência).
   - Vidro fumê: transparente de verdade (transmissão), com bordas champanhe.
------------------------------------------------------------------- */
const GOLD = new Color("#e2b54c");

function Gold() {
  return (
    <meshPhysicalMaterial
      color={GOLD}
      metalness={1}
      roughness={0.1}
      clearcoat={0.35}
      clearcoatRoughness={0.06}
      envMapIntensity={1.7}
    />
  );
}

function Smoke({ tint = "#1c1610" }: { tint?: string }) {
  // vidro fumê: transparente (o fundo do card e o ouro aparecem através), reflexos discretos
  return (
    <meshPhysicalMaterial
      color={tint}
      metalness={0.1}
      roughness={0.05}
      clearcoat={1}
      clearcoatRoughness={0.04}
      envMapIntensity={2}
      transparent
      opacity={0.3}
      depthWrite={false}
    />
  );
}

/** Painel de vidro fumê com arestas champanhe (bevel discreto). */
function Pane({
  size,
  position,
  rotation = [0, 0, 0],
}: {
  size: [number, number, number];
  position: [number, number, number];
  rotation?: [number, number, number];
}) {
  return (
    <RoundedBox args={size} radius={0.008} smoothness={3} position={position} rotation={rotation}>
      <Smoke />
      <Edges threshold={40} color="#f6dfae" transparent opacity={0.95} />
    </RoundedBox>
  );
}

/** Barra dourada fina (bevel discreto). */
function Bar({
  size,
  position,
  rotation = [0, 0, 0],
}: {
  size: [number, number, number];
  position: [number, number, number];
  rotation?: [number, number, number];
}) {
  const r = Math.min(0.01, Math.min(...size) / 3);
  return (
    <RoundedBox args={size} radius={r} smoothness={3} position={position} rotation={rotation}>
      <Gold />
    </RoundedBox>
  );
}

/* ------------------------------------------------------------------
   Esculturas
------------------------------------------------------------------- */

/** Posicionamento: painéis verticais de vidro e uma coluna dourada no centro. */
function Posicionamento() {
  return (
    <group>
      <Pane size={[0.42, 0.96, 0.028]} position={[-0.2, 0, -0.16]} rotation={[0, 0.5, 0]} />
      <Pane size={[0.38, 0.8, 0.028]} position={[0.22, -0.08, 0.08]} rotation={[0, -0.42, 0]} />
      <Pane size={[0.3, 0.6, 0.028]} position={[0.04, -0.18, -0.4]} rotation={[0, 0.1, 0]} />
      {/* coluna: fuste com capitel e base */}
      <Bar size={[0.075, 0.74, 0.075]} position={[0, -0.02, 0]} />
      <Bar size={[0.17, 0.034, 0.17]} position={[0, 0.37, 0]} />
      <Bar size={[0.13, 0.02, 0.13]} position={[0, 0.34, 0]} />
      <Bar size={[0.17, 0.034, 0.17]} position={[0, -0.41, 0]} />
      <Bar size={[0.13, 0.02, 0.13]} position={[0, -0.38, 0]} />
    </group>
  );
}

/** Visibilidade: anel dourado com volume atravessando um vidro. */
function Visibilidade() {
  return (
    <group>
      <Pane size={[0.4, 0.92, 0.028]} position={[0.12, 0, 0]} rotation={[0, -0.62, 0]} />
      <Pane size={[0.34, 0.68, 0.028]} position={[-0.26, -0.1, -0.32]} rotation={[0, 0.42, 0]} />
      <mesh rotation={[0, 0.55, 0]} position={[0, 0.02, 0]}>
        <torusGeometry args={[0.3, 0.058, 48, 160]} />
        <Gold />
      </mesh>
    </group>
  );
}

/** Tecnologia: cubos de vidro aninhados, contornos de ouro e um núcleo dourado. */
function Tecnologia() {
  const s = 0.6;
  const h = s / 2;
  const t = 0.02;
  // 12 arestas do cubo externo como barras de ouro finas
  const edges: Array<{ size: [number, number, number]; pos: [number, number, number] }> = [];
  for (const a of [-h, h])
    for (const b of [-h, h]) {
      edges.push({ size: [s + t, t, t], pos: [0, a, b] });
      edges.push({ size: [t, s + t, t], pos: [a, 0, b] });
      edges.push({ size: [t, t, s + t], pos: [a, b, 0] });
    }
  return (
    <group rotation={[0.42, 0.62, 0]}>
      <RoundedBox args={[s, s, s]} radius={0.01} smoothness={3}>
        <Smoke tint="#241c14" />
      </RoundedBox>
      {edges.map((e, i) => (
        <Bar key={i} size={e.size} position={e.pos} />
      ))}
      <RoundedBox args={[0.38, 0.38, 0.38]} radius={0.008} smoothness={3}>
        <Smoke tint="#1a140e" />
        <Edges threshold={40} color="#f4dba6" transparent opacity={0.75} />
      </RoundedBox>
      <Bar size={[0.15, 0.15, 0.15]} position={[0, 0, 0]} />
    </group>
  );
}

/* ------------------------------------------------------------------
   Símbolos do mockup: alvo com flecha (Posicionamento) e olho (Visibilidade)
------------------------------------------------------------------- */
const D = Math.PI / 180;

/** Forma extrudada em ouro, com chanfro. */
function Extruded({
  shape,
  depth = 0.05,
  bevel = 1,
  position,
  rotation,
}: {
  shape: Shape;
  depth?: number;
  bevel?: number;
  position?: [number, number, number];
  rotation?: [number, number, number];
}) {
  const geo = useMemo(() => {
    const g = new ExtrudeGeometry(shape, {
      depth,
      bevelEnabled: true,
      bevelThickness: 0.016 * bevel,
      bevelSize: 0.011 * bevel,
      bevelSegments: 5,
      curveSegments: 72,
    });
    g.translate(0, 0, -depth / 2);
    return g;
  }, [shape, depth, bevel]);
  return (
    <mesh geometry={geo} position={position} rotation={rotation}>
      <Gold />
    </mesh>
  );
}

/** Anel aberto (C) de raio externo R, espessura t, com abertura entre g0 e g1 (graus). */
function openRing(R: number, t: number, g0: number, g1: number) {
  const s = new Shape();
  s.absarc(0, 0, R, g1 * D, (g0 + 360) * D, false);
  s.absarc(0, 0, R - t, (g0 + 360) * D, g1 * D, true);
  s.closePath();
  return s;
}

function poly(pts: Array<[number, number]>) {
  const s = new Shape();
  pts.forEach(([x, y], i) => (i ? s.lineTo(x, y) : s.moveTo(x, y)));
  s.closePath();
  return s;
}

function Flare({ position, size = 0.34 }: { position: [number, number, number]; size?: number }) {
  const tex = useFlareTexture();
  return (
    <sprite position={position} scale={[size, size, size]}>
      <spriteMaterial map={tex} {...flareMaterialProps} toneMapped={false} />
    </sprite>
  );
}

/** Posicionamento: alvo de três anéis abertos com uma flecha dourada atravessando. */
function Alvo() {
  const parts = useMemo(
    () => ({
      outer: openRing(0.5, 0.075, 16, 84),
      mid: openRing(0.355, 0.07, 22, 80),
      inner: openRing(0.225, 0.06, 28, 78),
      bull: (() => {
        const s = new Shape();
        s.absarc(0, 0, 0.075, 0, Math.PI * 2, false);
        return s;
      })(),
      head: poly([
        [0.84, 0],
        [0.6, 0.1],
        [0.665, 0],
        [0.6, -0.1],
      ]),
      shaft: poly([
        [0.02, 0.016],
        [0.64, 0.016],
        [0.64, -0.016],
        [0.02, -0.016],
      ]),
      finA: poly([
        [0.5, 0.012],
        [0.37, 0.125],
        [0.3, 0.125],
        [0.41, 0.012],
      ]),
      finB: poly([
        [0.5, -0.012],
        [0.37, -0.125],
        [0.3, -0.125],
        [0.41, -0.012],
      ]),
    }),
    [],
  );
  return (
    <group scale={0.82} position={[-0.045, -0.02, 0]}>
      <Extruded shape={parts.outer} depth={0.06} />
      <Extruded shape={parts.mid} depth={0.06} />
      <Extruded shape={parts.inner} depth={0.06} />
      <Extruded shape={parts.bull} depth={0.07} bevel={0.8} />
      <group rotation={[0, 0, 42 * D]} position={[0, 0, 0.03]}>
        <Extruded shape={parts.shaft} depth={0.035} bevel={0.5} />
        <Extruded shape={parts.head} depth={0.05} bevel={0.7} />
        <Extruded shape={parts.finA} depth={0.035} bevel={0.5} />
        <Extruded shape={parts.finB} depth={0.035} bevel={0.5} />
      </group>
      <Flare position={[0.84 * Math.cos(42 * D), 0.84 * Math.sin(42 * D), 0.12]} size={0.5} />
    </group>
  );
}

function lens<T extends Path>(p: T, W: number, H: number): T {
  p.moveTo(-W, 0);
  p.bezierCurveTo(-W * 0.42, H * 1.42, W * 0.42, H * 1.42, W, 0);
  p.bezierCurveTo(W * 0.42, -H * 1.42, -W * 0.42, -H * 1.42, -W, 0);
  return p;
}

/** Visibilidade: olho em ouro, com íris em anéis e pupila espelhada. */
function Olho() {
  const parts = useMemo(() => {
    const outer: Shape = lens(new Shape(), 0.64, 0.33);
    outer.holes.push(lens(new Path(), 0.565, 0.265));
    const inner: Shape = lens(new Shape(), 0.5, 0.2);
    inner.holes.push(lens(new Path(), 0.47, 0.18));
    return { outer, inner };
  }, []);
  return (
    <group scale={0.9}>
      <Extruded shape={parts.outer} depth={0.06} />
      <Extruded shape={parts.inner} depth={0.02} bevel={0.4} position={[0, 0, -0.01]} />
      <mesh position={[0, 0, 0.01]}>
        <torusGeometry args={[0.285, 0.022, 32, 128]} />
        <Gold />
      </mesh>
      <mesh position={[0, 0, 0.03]}>
        <torusGeometry args={[0.2, 0.05, 40, 128]} />
        <Gold />
      </mesh>
      <mesh position={[0, 0, 0.04]} scale={[1, 1, 0.75]}>
        <sphereGeometry args={[0.125, 64, 48]} />
        <Gold />
      </mesh>
      <Flare position={[-0.64, 0, 0.1]} size={0.42} />
      <Flare position={[0.64, 0, 0.1]} size={0.42} />
    </group>
  );
}

const SCULPTURES: Record<string, () => ReactNode> = {
  posicionamento: () => <Alvo />,
  visibilidade: () => <Olho />,
  tecnologia: () => <Tecnologia />,
};

/* ------------------------------------------------------------------
   Estúdio de joalheria: faixas de luz brancas e champanhe com áreas escuras
   entre elas, para o ouro espelhado ter o que refletir.
------------------------------------------------------------------- */
function JewelStudio() {
  return (
    <Environment resolution={256} frames={1}>
      {/* fundo do estúdio: âmbar suave, para o ouro nunca refletir preto */}
      <color attach="background" args={["#a08f72"]} />
      <Lightformer form="rect" intensity={6} color="#fffaf0" position={[0, 3, 1]} scale={[4, 0.6, 1]} target={[0, 0, 0]} />
      <Lightformer form="rect" intensity={5} color="#fff6e6" position={[-2.6, 0.4, 1.2]} scale={[0.35, 4, 1]} target={[0, 0, 0]} />
      <Lightformer form="rect" intensity={4} color="#ffe8c2" position={[2.6, 0.2, 1.6]} scale={[0.35, 4, 1]} target={[0, 0, 0]} />
      <Lightformer form="rect" intensity={2.6} color="#fff3dc" position={[0, 0.3, 3.4]} scale={[3.4, 1.8, 1]} target={[0, 0, 0]} />
      <Lightformer form="rect" intensity={3} color="#ffffff" position={[0.6, 1.2, 3]} scale={[1.6, 0.25, 1]} target={[0, 0, 0]} />
      <Lightformer form="rect" intensity={1.4} color="#f3d39a" position={[0, 1, -3]} scale={[3, 1.4, 1]} target={[0, 0, 0]} />
    </Environment>
  );
}

/**
 * Escultura de um pilar.
 * Repouso: gira devagar e flutua. Hover/seleção: vira para o cursor e sobe um pouco.
 */
/** Símbolo do pilar (pin, olho, chip) com o ouro polido e espelhado. */
function PillarModel({ url }: { url: string }) {
  const model = useNormalizedModel(url, { fit: "max" });
  useMemo(() => {
    model.object.traverse((o) => {
      const m = o as Mesh;
      if (!m.isMesh) return;
      const mat = m.material as MeshStandardMaterial;
      if (mat.name === "Treville_Gold_Dark") return;
      mat.color.copy(GOLD);
      mat.metalness = 1;
      mat.roughness = 0.16;
      mat.envMapIntensity = 1.25;
      mat.transparent = false;
      mat.opacity = 1;
    });
  }, [model]);
  return <primitive object={model.object} />;
}

export function PillarScene({ url, slug, trackRef, mode }: Props) {
  const spin = useRef<Group>(null);
  const active = useRef(0);
  const auto = useRef(0);
  const intro = useRef(0);
  const reduce = useMemo(
    () => typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches,
    [],
  );
  const size = useThree((s) => s.size);
  // símbolos planos (alvo e olho): balançam de frente em vez de girar uma volta inteira
  const flat = slug === "posicionamento" || slug === "visibilidade";

  useFrame((state, dt) => {
    const g = spin.current;
    if (!g) return;
    const t = state.clock.elapsedTime;
    const st = store.get();
    const on = mode === "card" && (st.hovered === slug || st.selected === slug);
    active.current = MathUtils.damp(active.current, on ? 1 : 0, 6, dt);
    intro.current = Math.min(1, intro.current + dt / 1.4);
    const a = active.current;

    // cursor relativo ao card (-1..1)
    let px = 0;
    let py = 0;
    const el = trackRef?.current;
    if (el && pointer.active) {
      const r = el.getBoundingClientRect();
      const cx = ((pointer.x + 1) / 2) * window.innerWidth;
      const cy = ((1 - pointer.y) / 2) * window.innerHeight;
      px = MathUtils.clamp(((cx - r.left) / r.width) * 2 - 1, -1, 1);
      py = MathUtils.clamp(((cy - r.top) / r.height) * 2 - 1, -1, 1);
    }

    if (reduce) {
      g.rotation.set(0, -0.35, 0);
      return;
    }
    const speed = mode === "focus" ? 0.32 : 0.2;
    auto.current += dt * speed * (1 - a * 0.85);
    const introSpin = (1 - Math.pow(1 - intro.current, 3)) * Math.PI * 2;
    g.rotation.y = flat ? Math.sin(auto.current * 1.1) * 0.3 + introSpin + px * 0.5 * a : auto.current + introSpin + px * 0.45 * a;
    g.rotation.x = MathUtils.lerp(0, py * 0.18, a);
    g.position.y = Math.sin(t * 1.1 + slug.length) * 0.018 + a * 0.04;
  });

  // distância que faz a escultura caber na janela, em qualquer proporção
  const tanH = Math.tan((30 / 2) * (Math.PI / 180));
  const aspect = size.height > 0 ? size.width / size.height : 1;
  const need = mode === "focus" ? 0.64 : 0.86;
  const dist = Math.max(mode === "focus" ? 2.6 : 2.1, need / (tanH * aspect) + 0.4);

  return (
    <>
      <PerspectiveCamera makeDefault fov={30} position={[0, 0.06, dist]} near={0.05} far={40} />
      <JewelStudio />
      <directionalLight position={[2, 3, 2.5]} intensity={1.2} color="#fff4e2" />
      <group ref={spin}>{flat ? SCULPTURES[slug]?.() : url ? <PillarModel url={url} /> : SCULPTURES[slug]?.()}</group>
    </>
  );
}
