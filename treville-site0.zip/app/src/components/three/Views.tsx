"use client";

import { View } from "@react-three/drei";
import { Suspense } from "react";
import { SymbolScene } from "./SymbolScene";
import { use3D } from "./store";

type Fit = { floorPx: number; viewH: number; symbolPx: number };

/** Parte pesada (three + drei), carregada sob demanda. */
export default function SymbolView({
  variant,
  measure,
  readyKey,
}: {
  variant: "hero" | "contact";
  measure: () => Fit | null;
  readyKey: string;
}) {
  // com o zoom de um pilar aberto, só o modelo do zoom desenha
  const overlay = use3D((s) => s.overlay);
  return (
    <View className="gl-view-inner" visible={overlay === null}>
      <Suspense fallback={null}>
        <SymbolScene variant={variant} measure={measure} readyKey={readyKey} />
      </Suspense>
    </View>
  );
}
