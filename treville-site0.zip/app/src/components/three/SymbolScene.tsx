"use client";

import { Edges, PerspectiveCamera } from "@react-three/drei";
import { useFrame, useThree } from "@react-three/fiber";
import { useEffect, useMemo, useRef } from "react";
import {
  AdditiveBlending,
  DoubleSide,
  MathUtils,
  MeshBasicMaterial,
  MeshStandardMaterial,
  Plane,
  Vector3,
  type Group,
  type Material,
  type Mesh,
  type PerspectiveCamera as PCam,
  type Sprite,
} from "three";
import { GoldStudio, SYMBOL_URL, flareMaterialProps, useBeamTexture, useFlareTexture, useNormalizedModel } from "./shared";
import { drag, store } from "./store";

const FOV = 26;
const easeOut = (t: number) => 1 - Math.pow(1 - t, 3);

type Fit = { floorPx: number; viewH: number; symbolPx: number; viewW?: number; centerXPx?: number };

/** Painel de vidro: fino, quase invisível, com as quinas verticais acesas de dourado. */
function GlassPane({
  position,
  size,
  rotY = 0,
  glow = [0.9, 0.35],
  phase = 0,
  smoke = 0.06,
  thickness = 0.018,
}: {
  position: [number, number, number];
  size: [number, number];
  rotY?: number;
  /** intensidade da luz na quina [direita, esquerda] */
  glow?: [number, number];
  phase?: number;
  /** opacidade do vidro fumê (escurece o que está atrás) */
  smoke?: number;
  /** espessura do bloco de vidro */
  thickness?: number;
}) {
  const tex = useBeamTexture();
  const right = useRef<MeshBasicMaterial>(null);
  const left = useRef<MeshBasicMaterial>(null);
  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    if (right.current) right.current.opacity = glow[0] * (0.82 + Math.sin(t * 0.7 + phase) * 0.18);
    if (left.current) left.current.opacity = glow[1] * (0.8 + Math.sin(t * 0.55 + phase + 2) * 0.2);
  });
  const [w, h] = size;
  return (
    <group position={[position[0], position[1] + h / 2, position[2]]} rotation={[0, rotY, 0]}>
      <mesh>
        <boxGeometry args={[w, h, thickness]} />
        <meshPhysicalMaterial
          color={smoke > 0.08 ? "#16110b" : "#fff3dc"}
          transparent
          opacity={smoke}
          roughness={0.04}
          metalness={0}
          clearcoat={1}
          clearcoatRoughness={0.05}
          envMapIntensity={1}
          depthWrite={false}
        />
        <Edges threshold={30} color="#f3cf8a" transparent opacity={0.6} />
      </mesh>
      {/* quinas acesas: faixas finas de luz aditiva ao longo das bordas verticais */}
      <mesh position={[w / 2, 0, thickness / 2 + 0.003]} rotation={[0, 0, Math.PI / 2]}>
        <planeGeometry args={[h * 1.04, 0.065]} />
        <meshBasicMaterial ref={right} map={tex} color="#ffd88e" {...flareMaterialProps} toneMapped={false} />
      </mesh>
      <mesh position={[-w / 2, 0, thickness / 2 + 0.003]} rotation={[0, 0, Math.PI / 2]}>
        <planeGeometry args={[h * 1.04, 0.04]} />
        <meshBasicMaterial ref={left} map={tex} color="#ffd88e" {...flareMaterialProps} toneMapped={false} />
      </mesh>
    </group>
  );
}

/** Feixe de luz que atravessa o fundo na diagonal. */
function LightBeam({
  position,
  length,
  angle,
  thickness = 0.03,
  intensity = 0.9,
  speed = 0.35,
}: {
  position: [number, number, number];
  length: number;
  angle: number;
  thickness?: number;
  intensity?: number;
  speed?: number;
}) {
  const tex = useBeamTexture();
  const mat = useRef<MeshBasicMaterial>(null);
  useFrame(({ clock }) => {
    if (mat.current) mat.current.opacity = intensity * (0.75 + Math.sin(clock.elapsedTime * speed) * 0.25);
  });
  return (
    <mesh position={position} rotation={[0, 0, angle]}>
      <planeGeometry args={[length, thickness]} />
      <meshBasicMaterial ref={mat} map={tex} color="#ffcf73" {...flareMaterialProps} toneMapped={false} />
    </mesh>
  );
}

function Symbol({
  fit,
  variant,
  reduce,
  readyKey,
}: {
  fit: React.RefObject<Fit>;
  variant: "hero" | "contact";
  reduce: boolean;
  readyKey: string;
}) {
  const model = useNormalizedModel(SYMBOL_URL, { baseAtZero: true });
  useMemo(() => {
    model.object.traverse((o) => {
      const m = o as Mesh;
      if (!m.isMesh) return;
      const mat = m.material as MeshStandardMaterial;
      mat.color.setRGB(0.98, 0.76, 0.38);
      mat.metalness = 1;
      mat.roughness = 0.13;
      mat.envMapIntensity = 1.15;
      // brilho próprio leve: o ouro parece aceso por dentro
      mat.emissive.setRGB(0.32, 0.2, 0.06);
      mat.emissiveIntensity = 0.55;
    });
  }, [model]);
  const group = useRef<Group>(null);
  const flare = useRef<Sprite>(null);
  const flareTex = useFlareTexture();
  const cam = useThree((s) => s.camera) as PCam;
  const gl = useThree((s) => s.gl);
  const start = useRef<number | null>(null);
  const clip = useMemo(() => new Plane(new Vector3(0, 1, 0), 0), []);
  const mirrorInner = useRef<Group>(null);

  // cópia espelhada do símbolo para o reflexo no mármore (só soma luz à foto)
  const reflection = useMemo(() => {
    const clipBelow = new Plane(new Vector3(0, -1, 0), 0);
    const copy = model.object.clone(true);
    copy.traverse((o) => {
      const m = o as Mesh;
      if (!m.isMesh) return;
      const src = (Array.isArray(m.material) ? m.material[0] : m.material) as MeshStandardMaterial;
      const mat = new MeshStandardMaterial({
        color: src.color,
        metalness: 1,
        roughness: 0.2,
        transparent: true,
        opacity: 0.6,
        blending: AdditiveBlending,
        depthWrite: false,
        side: DoubleSide,
        clippingPlanes: [clipBelow],
        toneMapped: true,
      });
      // some suavemente conforme desce abaixo do piso
      mat.onBeforeCompile = (sh) => {
        sh.vertexShader = sh.vertexShader
          .replace("#include <common>", "#include <common>\nvarying float vWY;")
          .replace("#include <worldpos_vertex>", "#include <worldpos_vertex>\nvWY = (modelMatrix * vec4(transformed, 1.0)).y;");
        sh.fragmentShader = sh.fragmentShader
          .replace("#include <common>", "#include <common>\nvarying float vWY;")
          .replace(
            "#include <dithering_fragment>",
            "#include <dithering_fragment>\nfloat rf = pow(smoothstep(-0.5, 0.0, vWY), 1.8) * 0.9;\ngl_FragColor.rgb *= rf;\ngl_FragColor.a *= rf;",
          );
      };
      m.material = mat;
    });
    return copy;
  }, [model, variant]);

  // recorte no piso: o símbolo "nasce" de dentro do chão na abertura
  useEffect(() => {
    gl.localClippingEnabled = true;
    model.object.traverse((o) => {
      const m = o as Mesh;
      if (m.isMesh) {
        const mats = (Array.isArray(m.material) ? m.material : [m.material]) as Material[];
        mats.forEach((mat) => {
          mat.clippingPlanes = [clip];
          mat.needsUpdate = true;
        });
      }
    });
    store.setReady(readyKey);
  }, [model, gl, clip, variant, readyKey]);

  useFrame((state, dt) => {
    const g = group.current;
    const f = fit.current;
    if (!g || !f || f.viewH <= 0) return;
    const t = state.clock.elapsedTime;

    // --- câmera: posiciona para a base do símbolo cair na linha do piso da foto
    const tanH = Math.tan(MathUtils.degToRad(FOV / 2));
    const d = f.viewH / (2 * tanH * f.symbolPx);
    const ndc = 1 - (2 * f.floorPx) / f.viewH;
    // câmera baixa (perto do chão) e inclinada para cima, mantendo a base na linha do piso
    const camH = 0.3;
    const pitch = Math.atan(-ndc * tanH) - Math.atan(camH / d);
    const camY = camH;
    const aspect = f.viewW ? f.viewW / f.viewH : cam.aspect;
    const ndcX = f.viewW && f.centerXPx !== undefined ? (2 * f.centerXPx) / f.viewW - 1 : 0;
    const camX = -ndcX * d * tanH * aspect;
    cam.position.set(camX, camY, d);
    cam.lookAt(camX, camY + Math.tan(pitch) * d, 0);

    // --- entrada: sobe do piso
    if (start.current === null) start.current = t + 0.35;
    const k = reduce ? 1 : MathUtils.clamp((t - start.current) / 1.8, 0, 1);
    const rise = (1 - easeOut(k)) * -1.05;

    // --- movimento: a logo fica parada; só gira em torno do próprio eixo enquanto é arrastada
    // e, ao soltar, volta ao lugar com uma mola suave
    const rest = variant === "hero" ? -0.3 : -0.2;
    if (!drag.active) {
      // passos fixos: a volta leva o mesmo tempo em qualquer taxa de quadros
      let left = Math.min(dt, 0.5);
      while (left > 0) {
        const h = Math.min(left, 1 / 120);
        drag.vel += (-60 * drag.angle - 9 * drag.vel) * h;
        drag.angle += drag.vel * h;
        left -= h;
      }
      if (Math.abs(drag.angle) < 0.0005 && Math.abs(drag.vel) < 0.002) {
        drag.angle = 0;
        drag.vel = 0;
      }
    }
    g.rotation.y = rest + drag.angle;
    g.rotation.x = 0;
    g.position.y = rise + 0.004;

    if (mirrorInner.current) {
      mirrorInner.current.rotation.copy(g.rotation);
      mirrorInner.current.position.y = g.position.y;
    }

    if (flare.current) {
      const pulse = 0.85 + Math.sin(t * 1.4) * 0.15;
      const s = 0.26 * pulse * easeOut(MathUtils.clamp((t - (start.current ?? 0) - 1.2) / 0.8, 0, 1));
      flare.current.scale.set(s, s, s);
    }
  });

  return (
    <>
      <group ref={group} rotation={[0, variant === "hero" ? -0.3 : -0.2, 0]}>
        <primitive object={model.object} />
        <sprite ref={flare} position={[0.53, 0.94, 0.14]} scale={0}>
          <spriteMaterial map={flareTex} {...flareMaterialProps} toneMapped={false} />
        </sprite>
      </group>
      {reflection && (
        <group scale={[1, -1, 1]}>
          <group ref={mirrorInner}>
            <primitive object={reflection} />
          </group>
        </group>
      )}
    </>
  );
}

/** Brilho dourado no piso, logo abaixo do símbolo. */
function FloorGlow() {
  const tex = useFlareTexture();
  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.002, 0.05]} scale={[2.4, 0.9, 1]}>
      <planeGeometry />
      <meshBasicMaterial map={tex} transparent opacity={0.35} depthWrite={false} blending={AdditiveBlending} toneMapped={false} />
    </mesh>
  );
}

/**
 * Cena do símbolo dentro de um <View>.
 * - hero: apoiado na linha do piso da foto, com reflexo somado ao mármore e vidros atrás.
 * - contact: centralizado, com dois vidros.
 */
export function SymbolScene({
  variant,
  measure,
  readyKey,
}: {
  variant: "hero" | "contact";
  /** devolve as medidas da janela (px) */
  measure: () => Fit | null;
  readyKey: string;
}) {
  const fit = useRef<Fit>({ floorPx: 0, viewH: 0, symbolPx: 1 });
  const reduce = useMemo(
    () => typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches,
    [],
  );

  useEffect(() => {
    const update = () => {
      const m = measure();
      if (m) fit.current = m;
    };
    update();
    const ro = new ResizeObserver(update);
    ro.observe(document.documentElement);
    window.addEventListener("resize", update);
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", update);
    };
  }, [measure]);

  return (
    <>
      <PerspectiveCamera makeDefault fov={FOV} near={0.05} far={60} />
      <GoldStudio intensity={variant === "hero" ? 1.1 : 1} />
      <directionalLight position={[3, 4, 3]} intensity={1.4} color="#ffe2b0" />
      <pointLight position={[0.2, 0.7, 0.45]} intensity={2.2} distance={3.2} color="#f1c878" />
      <pointLight position={[-1.2, 1.4, -1.6]} intensity={0.6} distance={4} color="#9fb4d8" />

      <Symbol fit={fit} variant={variant} reduce={reduce} readyKey={readyKey} />

      {variant === "hero" ? (
        <>
          {/* composição do mockup (unidade = altura do logo; centro do logo em x = 0) */}
          {/* bloco de vidro que envolve as duas letras da direita */}
          <GlassPane position={[0.3, 0, -0.12]} size={[0.86, 1.12]} rotY={-0.3} thickness={0.62} glow={[0.95, 0.6]} phase={0.3} />
          {/* painel alto à direita, um pouco à frente */}
          <GlassPane position={[0.74, 0, 0.28]} size={[0.4, 0.7]} rotY={-0.52} thickness={0.035} glow={[0.55, 0.95]} phase={2.6} />
          {/* painel baixo à esquerda, na frente */}
          <GlassPane position={[-0.62, 0, 0.18]} size={[0.24, 0.4]} rotY={0.45} thickness={0.03} glow={[0.65, 0.3]} phase={2} />
          {/* painel estreito à esquerda, atrás */}
          <GlassPane position={[-0.8, 0, -0.35]} size={[0.16, 0.62]} rotY={0.35} thickness={0.02} glow={[0.6, 0.25]} phase={1.1} />
          {/* placas ao fundo, só para dar profundidade */}
          <GlassPane position={[-0.25, 0, -1.3]} size={[0.6, 1.5]} rotY={0.15} glow={[0.35, 0.2]} phase={3.4} />
          <GlassPane position={[1.3, 0, -1.1]} size={[0.56, 1.35]} rotY={-0.3} glow={[0.45, 0.3]} phase={4.2} />
          <LightBeam position={[1.2, 1.0, -1.3]} length={3.2} angle={0.22} thickness={0.03} intensity={0.85} />
          <LightBeam position={[-0.6, 1.5, -1.9]} length={3.4} angle={-0.06} thickness={0.02} intensity={0.45} speed={0.25} />
          <FloorGlow />
        </>
      ) : (
        <>
          {/* sala do contato: dois vidros altos atrás do logo, piso espelhado */}
          <GlassPane position={[-0.52, 0, 0.2]} size={[0.56, 1.36]} rotY={0.42} thickness={0.03} glow={[0.8, 0.5]} phase={0.6} />
          <GlassPane position={[0.5, 0, 0.18]} size={[0.6, 1.5]} rotY={-0.36} thickness={0.03} glow={[0.9, 0.6]} phase={2.2} />
          <FloorGlow />
        </>
      )}
    </>
  );
}
