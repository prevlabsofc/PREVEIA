"use client";

import { useSyncExternalStore } from "react";

/**
 * Estado mínimo compartilhado entre o DOM e o canvas 3D
 * (o <View> do drei não leva contexto React para dentro do canvas).
 */
type State = {
  /** o canvas 3D montou (WebGL disponível) */
  gl: boolean;
  /** modelos carregados, por chave */
  ready: Record<string, boolean>;
  /** pilar aberto no zoom (null = fechado) */
  overlay: string | null;
  /** pilar com o cursor/dedo em cima */
  hovered: string | null;
  /** pilar selecionado (clique: destaque de 5%) */
  selected: string | null;
};

let state: State = { gl: false, ready: {}, overlay: null, hovered: null, selected: null };
const subs = new Set<() => void>();

export const store = {
  get: () => state,
  set(patch: Partial<State>) {
    state = { ...state, ...patch };
    subs.forEach((f) => f());
  },
  setReady(key: string) {
    if (state.ready[key]) return;
    state = { ...state, ready: { ...state.ready, [key]: true } };
    subs.forEach((f) => f());
  },
  subscribe(f: () => void) {
    subs.add(f);
    return () => subs.delete(f);
  },
};

const server: State = { gl: false, ready: {}, overlay: null, hovered: null, selected: null };
export function use3D<T>(select: (s: State) => T): T {
  return useSyncExternalStore(store.subscribe, () => select(store.get()), () => select(server));
}

/** Ponteiro normalizado (-1..1), lido a cada frame sem re-render. */
export const pointer = { x: 0, y: 0, active: false };

/** Giro manual da logo: ângulo (rad) em relação ao repouso, velocidade da mola e se está sendo segurada. */
export const drag = { angle: 0, vel: 0, active: false };
