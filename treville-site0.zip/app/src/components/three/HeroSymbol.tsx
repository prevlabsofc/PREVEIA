"use client";

/* eslint-disable @next/next/no-img-element */
import dynamic from "next/dynamic";
import { useCallback, useEffect, useRef } from "react";
import { drag, use3D } from "./store";

const SymbolView = dynamic(() => import("./Views"), { ssr: false });

/**
 * Símbolo do hero: 3D sobre o piso da foto quando há WebGL;
 * o 2D com reflexo fica por baixo como reserva e some quando o 3D carrega.
 */
/**
 * Superfície que recebe o arrasto: segurar e mover para os lados gira a logo em torno do
 * próprio eixo; ao soltar, ela volta ao lugar. No celular o scroll vertical continua livre.
 */
function DragSurface() {
  const last = useRef(0);
  return (
    <div
      className="symbol-drag"
      aria-hidden="true"
      onPointerDown={(e) => {
        e.currentTarget.setPointerCapture(e.pointerId);
        last.current = e.clientX;
        drag.active = true;
        drag.vel = 0;
      }}
      onPointerMove={(e) => {
        if (!drag.active) return;
        drag.angle += (e.clientX - last.current) * 0.012;
        last.current = e.clientX;
      }}
      onPointerUp={() => {
        drag.active = false;
        // volta pelo caminho mais curto
        drag.angle = ((((drag.angle + Math.PI) % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI)) - Math.PI;
      }}
      onPointerCancel={() => {
        drag.active = false;
      }}
    />
  );
}

export function HeroSymbol() {
  const viewRef = useRef<HTMLDivElement>(null);
  const anchorRef = useRef<HTMLDivElement>(null);
  const gl = use3D((s) => s.gl);
  const ready = use3D((s) => !!s.ready.hero);

  // a janela 3D ocupa a largura toda da tela (sem cortes retos nos vidros e no reflexo)
  useEffect(() => {
    const bleed = () => {
      const col = anchorRef.current?.parentElement?.getBoundingClientRect();
      const v = viewRef.current;
      if (!col || !v) return;
      v.style.left = `${-col.left}px`;
      v.style.right = `${-(document.documentElement.clientWidth - col.right)}px`;
    };
    bleed();
    window.addEventListener("resize", bleed);
    return () => window.removeEventListener("resize", bleed);
  }, []);

  const measure = useCallback(() => {
    const v = viewRef.current?.getBoundingClientRect();
    const a = anchorRef.current?.getBoundingClientRect();
    if (!v || !a || v.height === 0) return null;
    const mobile = window.innerWidth <= 920;
    const vw = document.documentElement.clientWidth;
    // desktop (mockup): logo grande, ~62% da altura do hero, centrado em ~68% da largura
    // desktop: o maior possível sem passar por baixo do header
    const headerBottom = (document.querySelector(".site-header .bar")?.getBoundingClientRect().bottom ?? 104) - v.top;
    const floor = a.top - v.top;
    const symbolH = mobile
      ? Math.min(a.width * 0.72, 380) * 0.86
      : Math.min(v.height * 0.72, vw * 0.36, floor - headerBottom - 8);
    const centerX = mobile ? a.left + a.width / 2 : vw * 0.68;
    return {
      floorPx: a.top - v.top,
      viewH: v.height,
      viewW: v.width,
      centerXPx: centerX - v.left,
      symbolPx: symbolH,
    };
  }, []);

  return (
    <>
      <div ref={anchorRef} className="symbol-anchor" style={{ opacity: ready ? 0 : 1, transition: "opacity .6s" }}>
        <img className="symbol-2d symbol-2d--front" src="/images/treville-symbol.webp" alt="" width={900} height={765} />
        <img className="symbol-2d symbol-2d--reflection" src="/images/treville-symbol.webp" alt="" width={900} height={765} />
      </div>
      <div ref={viewRef} className="gl-view">
        {gl && (
          <SymbolView variant="hero" measure={measure} readyKey="hero" />
        )}
      </div>
      <DragSurface />
    </>
  );
}

export function ContactSymbol() {
  const viewRef = useRef<HTMLDivElement>(null);
  const gl = use3D((s) => s.gl);
  const ready = use3D((s) => !!s.ready.contact);

  const measure = useCallback(() => {
    const v = viewRef.current?.getBoundingClientRect();
    if (!v || v.height === 0) return null;
    if (window.innerWidth > 920) {
      // desktop (mockup 1672px): janela de 610 de largura; logo de 285 de altura, base em y=525, centro em x=305
      const u = v.width / 610;
      return { floorPx: 525 * u, viewH: v.height, viewW: v.width, centerXPx: 305 * u, symbolPx: 285 * u };
    }
    const symbolPx = Math.min(v.width * 0.82 * (765 / 900), v.height * 0.55);
    return { floorPx: v.height / 2 + symbolPx / 2, viewH: v.height, viewW: v.width, centerXPx: v.width / 2, symbolPx };
  }, []);

  return (
    <>
      <img
        className="symbol-2d symbol-2d--front"
        src="/images/treville-symbol.webp"
        alt=""
        width={900}
        height={765}
        loading="lazy"
        style={{ opacity: ready ? 0 : 1, transition: "opacity .6s" }}
      />
      <div ref={viewRef} className="gl-view">
        {gl && (
          <SymbolView variant="contact" measure={measure} readyKey="contact" />
        )}
      </div>
      <DragSurface />
    </>
  );
}
