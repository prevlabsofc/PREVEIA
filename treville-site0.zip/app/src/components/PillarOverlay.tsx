"use client";

/* eslint-disable @next/next/no-img-element */
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { useCallback, useEffect, useRef, useState, type ComponentType } from "react";
import { createPortal } from "react-dom";
import type { Pilar } from "@/content/pilares";
import { ArrowRight, CloseIcon } from "./icons";
import { useSmoothScroll } from "./SmoothScroll";
import { store } from "./three/store";

export type OpenPillar = { p: Pilar; rect: DOMRect; el: HTMLElement };

type ViewProps = {
  url: string;
  slug: string;
  mode: "card" | "focus";
  trackRef?: React.RefObject<HTMLElement | null>;
};

const EASE = [0.2, 0.7, 0.2, 1] as const;

/**
 * Zoom do pilar: o card cresce até ocupar a tela, o modelo vem para o centro girando
 * e a frase entra palavra por palavra. Fecha no X, no Esc e no "voltar" do celular.
 */
export function PillarOverlay({
  open,
  onClose,
  PillarView,
}: {
  open: OpenPillar | null;
  onClose: () => void;
  PillarView: ComponentType<ViewProps>;
}) {
  const { lenis } = useSmoothScroll();
  const reduce = useReducedMotion();
  const closeBtn = useRef<HTMLButtonElement>(null);
  const panel = useRef<HTMLDivElement>(null);
  const pushed = useRef(false);
  const last = useRef<OpenPillar | null>(null);
  if (open) last.current = open;

  const requestClose = useCallback(() => {
    if (pushed.current) {
      pushed.current = false;
      history.back(); // o popstate fecha
    } else onClose();
  }, [onClose]);

  useEffect(() => {
    if (!open) return;
    store.set({ overlay: open.p.slug, hovered: null });
    lenis?.stop();
    document.documentElement.style.overflow = "hidden";

    history.pushState({ pillar: open.p.slug }, "");
    pushed.current = true;
    const onPop = () => {
      pushed.current = false;
      onClose();
    };
    window.addEventListener("popstate", onPop);

    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") requestClose();
      if (e.key === "Tab" && panel.current) {
        // mantém o foco dentro do zoom
        const f = panel.current.querySelectorAll<HTMLElement>("button, a[href]");
        if (!f.length) return;
        const first = f[0];
        const lastEl = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          lastEl.focus();
        } else if (!e.shiftKey && document.activeElement === lastEl) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    window.addEventListener("keydown", onKey);
    const t = window.setTimeout(() => closeBtn.current?.focus({ preventScroll: true }), 80);

    return () => {
      window.removeEventListener("popstate", onPop);
      window.removeEventListener("keydown", onKey);
      clearTimeout(t);
      lenis?.start();
      document.documentElement.style.overflow = "";
    };
  }, [open, lenis, onClose, requestClose]);

  // o zoom vai direto para o <body>, acima de tudo (inclusive do header)
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const cur = open ?? last.current;
  const r = cur?.rect;
  const from = r
    ? { top: r.top, left: r.left, width: r.width, height: r.height, borderRadius: 20 }
    : { top: 0, left: 0, width: 0, height: 0, borderRadius: 20 };

  const words = cur ? cur.p.frase.split(" ") : [];

  // destino do zoom: um card grande no centro (não cobre a página toda)
  const target = (() => {
    if (typeof window === "undefined") return { top: 0, left: 0, width: 0, height: 0 };
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const narrow = vw <= 920;
    const width = narrow ? vw - 24 : Math.min(1120, vw * 0.88);
    const height = narrow ? Math.min(vh - 40, 760) : Math.min(660, vh * 0.84);
    return { top: (vh - height) / 2, left: (vw - width) / 2, width, height };
  })();

  if (!mounted) return null;

  return createPortal(
    <AnimatePresence
      onExitComplete={() => {
        store.set({ overlay: null });
        last.current?.el.focus({ preventScroll: true });
      }}
    >
      {open && cur && (
        <motion.div
          key={cur.p.slug}
          className="pz-backdrop"
          onPointerDown={(e) => e.target === e.currentTarget && requestClose()}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, transition: { duration: 0.45, delay: 0.1 } }}
          transition={{ duration: 0.4 }}
        >
          <motion.div
            ref={panel}
            className="pz-panel glass"
            role="dialog"
            aria-modal="true"
            aria-labelledby="pz-title"
            initial={reduce ? { ...from, opacity: 0 } : from}
            animate={{ ...target, borderRadius: 28, opacity: 1 }}
            exit={{ ...from, opacity: reduce ? 0 : 1, transition: { duration: 0.55, ease: EASE } }}
            transition={{ duration: reduce ? 0.2 : 0.75, ease: EASE }}
          >
            <motion.div
              className="pz-content"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1, transition: { delay: 0.35, duration: 0.5 } }}
              exit={{ opacity: 0, transition: { duration: 0.2 } }}
            >
              <div className="pz-top">
                <p className="eyebrow">
                  <span className="pz-num">{cur.p.n}</span> {cur.p.label}
                </p>
                <button ref={closeBtn} type="button" className="menu-btn pz-close" aria-label="Fechar" onClick={requestClose}>
                  <CloseIcon />
                </button>
              </div>

              <div className="pz-model" aria-hidden="true">
                <span className="pz-glow" />
                {cur.p.art ? (
                  <img className="pz-art" src={cur.p.art} alt="" width={760} height={839} draggable={false} />
                ) : (
                  <span className="gl-view">
                    <PillarView url={cur.p.model} slug={cur.p.slug} mode="focus" />
                  </span>
                )}
              </div>

              <div className="pz-text">
                <h2 id="pz-title" className="h2 pz-frase">
                  {words.map((w, i) => (
                    <span key={i}>
                      <span className="mask-word">
                        <motion.span
                          initial={{ y: reduce ? "0%" : "105%", opacity: reduce ? 0 : 1 }}
                          animate={{
                            y: "0%",
                            opacity: 1,
                            transition: { delay: 0.55 + i * 0.06, duration: 0.9, ease: EASE },
                          }}
                        >
                          {w}
                        </motion.span>
                      </span>
                      {i < words.length - 1 ? " " : null}
                    </span>
                  ))}
                </h2>
                <motion.p
                  className="lead"
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0, transition: { delay: 0.95, duration: 0.7, ease: EASE } }}
                >
                  {cur.p.desc}
                </motion.p>
                <motion.div
                  className="actions"
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0, transition: { delay: 1.1, duration: 0.7, ease: EASE } }}
                >
                  <a
                    className="btn btn--gold"
                    href="#contato"
                    onClick={(e) => {
                      e.preventDefault();
                      requestClose();
                      window.setTimeout(() => {
                        const el = document.getElementById("contato");
                        if (lenis && el) lenis.scrollTo(el, { offset: -100 });
                        else el?.scrollIntoView({ behavior: "smooth" });
                      }, 650);
                    }}
                  >
                    Iniciar uma conversa <ArrowRight />
                  </a>
                </motion.div>
              </div>
            </motion.div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body,
  );
}
