import Image from "next/image";
import { Glass } from "../Glass";
import { ArrowRight } from "../icons";
import { SectionRail } from "../SectionRail";
import { HeroSymbol } from "../three/HeroSymbol";

// quebras do mockup: "Autoridade não se" / "improvisa." / "Constrói-se."
const LINES = [["Autoridade", "não", "se"], ["improvisa."]];
const WORDS = LINES.flat();

const MOCK_SPOTS = [
  { href: "#inicio", label: "Início", style: { left:"36.483%",top:"5.526%",width:"3.349%",height:"5.313%" } },
  { href: "#filosofia", label: "Filosofia", style: { left:"42.105%",top:"5.526%",width:"4.007%",height:"5.313%" } },
  { href: "#pilares", label: "Pilares", style: { left:"48.684%",top:"5.526%",width:"3.230%",height:"5.313%" } },
  { href: "#socios", label: "Sócios", style: { left:"54.486%",top:"5.526%",width:"3.170%",height:"5.313%" } },
  { href: "#contato", label: "Contato", style: { left:"60.227%",top:"5.526%",width:"3.888%",height:"5.313%" } },
  { href: "#contato", label: "Iniciar uma conversa", style: { left:"80.562%",top:"5.207%",width:"13.876%",height:"5.207%" } },
  { href: "#inicio", label: "TRÉVILLE", style: { left:"7.057%",top:"4.782%",width:"14.952%",height:"5.845%" } },
  { href: "#pilares", label: "Explorar a TRÉVILLE", style: { left:"7.715%",top:"71.838%",width:"16.029%",height:"5.845%" } },
  { href: "#contato", label: "Iniciar uma conversa", style: { left:"24.940%",top:"71.838%",width:"14.234%",height:"5.845%" } },
];

export function Hero() {
  return (
    <section id="inicio" className="band hero" aria-labelledby="hero-title">
      {/* desktop: a primeira dobra é a imagem do mockup, sem alterações; os links ficam por cima */}
      <div className="hero-mock" aria-hidden="true">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/images/hero-mockup.webp" alt="" width={1672} height={941} fetchPriority="high" draggable={false} />
        {MOCK_SPOTS.map((m, i) => (
          <a key={i} href={m.href} tabIndex={-1} style={m.style} className="hero-spot">
            {m.label}
          </a>
        ))}
      </div>

      <div className="hero-bg" aria-hidden="true">
        <Image src="/images/hero-bg.webp" alt="" fill priority sizes="100vw" />
      </div>

      {/* palco: a coluna da direita recebe o símbolo apoiado na linha do piso */}
      <div className="hero-stage" aria-hidden="true">
        <div className="wrap">
          <span />
          <div className="cols">
            <div className="stage-col">
              <HeroSymbol />
            </div>
          </div>
        </div>
      </div>

      <div className="wrap">
        <SectionRail index={1} />
        <div className="inner">
          <Glass className="hero-card intro-card">
            <p className="eyebrow intro-in" style={{ "--d": 0.95 } as React.CSSProperties}>
              Estratégia · Tecnologia · Posicionamento
            </p>
            <h1 id="hero-title" className="h1">
              {LINES.map((line, li) => (
                <span key={li} className="hero-line">
                  {line.map((w, wi) => {
                    const i = LINES.slice(0, li).flat().length + wi;
                    return (
                      <span key={wi}>
                        <span className="mask-word">
                          <span className="intro-word" style={{ "--d": 1.05 + i * 0.07 } as React.CSSProperties}>
                            {w}
                          </span>
                        </span>{" "}
                      </span>
                    );
                  })}
                </span>
              ))}
              <span className="mask-word hero-last">
                <em className="intro-word intro-gold" style={{ "--d": 1.05 + WORDS.length * 0.07 + 0.12 } as React.CSSProperties}>
                  Constrói-se.
                </em>
              </span>
            </h1>
            <p className="lead intro-in" style={{ "--d": 1.55 } as React.CSSProperties}>
              Estratégia, tecnologia e posicionamento para advogados e escritórios de advocacia que desejam construir
              uma reputação à altura da sua excelência.
            </p>
            <div className="actions intro-in" style={{ "--d": 1.7 } as React.CSSProperties}>
              <a className="btn btn--gold" href="#pilares">
                <span>
                  Explorar a <span translate="no">TRÉVILLE</span>
                </span>
                <ArrowRight />
              </a>
              <a className="btn btn--ghost" href="#contato">
                Iniciar uma conversa
              </a>
            </div>
          </Glass>
        </div>
      </div>

      <div className="scroll-cue intro-in" style={{ "--d": 2 } as React.CSSProperties} aria-hidden="true">
        <i />
        Scroll
        <svg viewBox="0 0 12 12" width="9" height="9" fill="none" stroke="currentColor" strokeWidth="1.3">
          <path d="M3 4.5l3 3 3-3" />
        </svg>
      </div>

      {/* ícone de mouse no canto inferior direito, como no mockup */}
      <div className="scroll-mouse intro-in" style={{ "--d": 2.1 } as React.CSSProperties} aria-hidden="true">
        <i />
      </div>
    </section>
  );
}
