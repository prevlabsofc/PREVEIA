"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { SOCIOS } from "@/content/socios";
import { Carousel } from "../Carousel";
import { Glass } from "../Glass";
import { ArrowRight } from "../icons";
import { Reveal, RevealTitle } from "../Reveal";
import { SectionRail } from "../SectionRail";

function Silhouette({ variant }: { variant: number }) {
  const paths = [
    "M150 70c-26 0-44 20-44 48 0 20 8 38 20 48l-2 18c-40 8-74 30-84 70l-6 101h232l-6-101c-10-40-44-62-84-70l-2-18c12-10 20-28 20-48 0-28-18-48-44-48z",
    "M150 64c-30 0-50 24-50 54 0 14 2 34-8 58-6 14-6 28 6 34l26-6 2 6c-44 6-80 28-90 72l-6 73h240l-6-73c-10-44-46-66-90-72l2-6 26 6c12-6 12-20 6-34-10-24-8-44-8-58 0-30-20-54-50-54z",
    "M152 72c-24 0-42 18-42 46 0 22 8 40 20 50l-2 16c-42 8-76 30-86 70l-6 101h232l-6-101c-10-40-44-62-86-70l-2-16c12-10 20-28 20-50 0-28-18-46-42-46z",
  ];
  const gid = `rim-${variant}`;
  return (
    <svg className="silhouette" viewBox="0 0 300 375" preserveAspectRatio="xMidYMax slice" aria-hidden="true">
      <defs>
        <linearGradient id={gid} x1={variant === 2 ? 1 : 0} x2={variant === 2 ? 0 : 1}>
          <stop offset="0" stopColor="#e8c47e" stopOpacity=".9" />
          <stop offset=".42" stopColor="#2a2014" stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={paths[variant % 3]} transform="translate(0 20)" fill="#0b0907" stroke={`url(#${gid})`} strokeWidth="2.5" />
    </svg>
  );
}

export function Socios() {
  const [open, setOpen] = useState<number | null>(null);

  // Esc fecha; clique fora fecha
  useEffect(() => {
    if (open === null) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(null);
    const onDown = (e: PointerEvent) => {
      if (!(e.target as Element).closest(".slot")) setOpen(null);
    };
    window.addEventListener("keydown", onKey);
    window.addEventListener("pointerdown", onDown);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("pointerdown", onDown);
    };
  }, [open]);

  return (
    <section id="socios" className="band people" aria-labelledby="soc-title">
      <div className="people-bg" aria-hidden="true">
        <Image src="/images/socios-bg.webp" alt="" fill sizes="100vw" />
      </div>
      <div className="people-veil" aria-hidden="true" />
      <div className="wrap">
        <SectionRail index={4} />
        <div className="inner">
          <div className="copy">
            <Reveal as="p" className="eyebrow">
              Sócios
            </Reveal>
            <RevealTitle id="soc-title" className="h2" parts={["Estratégia é construída por pessoas."]} delay={0.08} />
            <Reveal as="p" className="lead" delay={0.16}>
              Quem conduz o seu projeto do diagnóstico à entrega, sem intermediários.
            </Reveal>
            <Reveal className="actions" delay={0.24}>
              <a className="btn btn--ghost" href="#contato">
                Conheça os sócios <ArrowRight />
              </a>
            </Reveal>
          </div>

          <Carousel className="team" label="Sócios">
            {SOCIOS.map((s, i) => (
              <Reveal key={i} role="listitem" className="slot" delay={0.12 + i * 0.12}>
                <Glass
                  as="button"
                  type="button"
                  className={`person${open === i ? " is-open" : ""}`}
                  aria-expanded={open === i}
                  aria-controls={`socio-${i}`}
                  onClick={() => setOpen(open === i ? null : i)}
                >
                  {s.foto ? (
                    <Image className="photo" src={s.foto} alt="" fill sizes="(max-width: 920px) 72vw, 420px" />
                  ) : (
                    <Silhouette variant={i} />
                  )}
                  <span className="shade" />
                  <span className="meta">
                    <strong>{s.nome}</strong>
                    <span>{s.cargo}</span>
                  </span>
                  <span className="round-arrow" aria-hidden="true">
                    <ArrowRight />
                  </span>
                </Glass>
                <div id={`socio-${i}`} className={`person-desc${open === i ? " is-open" : ""}`} role="region" aria-label={`Sobre ${s.nome}`}>
                  <p>{s.descricao}</p>
                  {s.linkedin.startsWith("http") && (
                    <a href={s.linkedin} target="_blank" rel="noopener noreferrer" tabIndex={open === i ? 0 : -1}>
                      LinkedIn <ArrowRight />
                    </a>
                  )}
                </div>
              </Reveal>
            ))}
          </Carousel>
        </div>
      </div>
    </section>
  );
}
