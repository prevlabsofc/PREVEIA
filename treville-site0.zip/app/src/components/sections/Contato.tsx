import { LINKS } from "@/content/links";
import { Glass } from "../Glass";
import { ArrowRight, Instagram, LinkedIn, WhatsApp } from "../icons";
import { Reveal, RevealTitle } from "../Reveal";
import { SectionRail } from "../SectionRail";
import { ContactSymbol } from "../three/HeroSymbol";

const CANAIS = [
  { href: LINKS.whatsapp, Icon: WhatsApp, t: "WhatsApp", d: "Fale conosco" },
  { href: LINKS.instagram, Icon: Instagram, t: "Instagram", d: "Acompanhe nossa jornada" },
  { href: LINKS.linkedin, Icon: LinkedIn, t: "LinkedIn", d: "Conecte-se" },
];

export function Contato() {
  return (
    <section id="contato" className="band contact" aria-labelledby="con-title">
      <div className="wrap">
        <SectionRail index={5} />
        <div className="inner">
          <div className="copy">
            <Reveal as="p" className="eyebrow">
              Contato
            </Reveal>
            <RevealTitle id="con-title" className="h2" parts={["O próximo movimento começa com", { em: "uma conversa." }]} delay={0.08} />
            <Reveal as="p" className="lead" delay={0.16}>
              Conte onde o seu escritório está hoje e onde quer chegar. Respondemos em até um dia útil.
            </Reveal>
            {/* este botão nunca some */}
            <div className="actions">
              <a className="btn btn--gold" href={LINKS.whatsapp} target="_blank" rel="noopener noreferrer">
                Iniciar uma conversa <ArrowRight />
              </a>
            </div>
          </div>

          <Reveal className="contact-media" delay={0.2} aria-hidden="true">
            <ContactSymbol />
          </Reveal>

          <Reveal className="contact-links-wrap" delay={0.28}>
            <Glass as="ul" className="contact-links">
              {CANAIS.map(({ href, Icon, t, d }) => (
                <li key={t}>
                  <a href={href} target="_blank" rel="noopener noreferrer">
                    <span className="ic">
                      <Icon />
                    </span>
                    <span>
                      <strong>{t}</strong>
                      <span>{d}</span>
                    </span>
                    <ArrowRight className="arr" />
                  </a>
                </li>
              ))}
            </Glass>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
