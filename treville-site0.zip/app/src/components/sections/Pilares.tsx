"use client";

/* eslint-disable @next/next/no-img-element */
import dynamic from "next/dynamic";
import { useCallback, useEffect, useRef, useState } from "react";
import { PILARES, type Pilar } from "@/content/pilares";
import { Carousel } from "../Carousel";
import { Glass } from "../Glass";
import { ArrowRight } from "../icons";
import { PillarOverlay, type OpenPillar } from "../PillarOverlay";
import { Reveal, RevealTitle } from "../Reveal";
import { SectionRail } from "../SectionRail";
import { store, use3D } from "../three/store";

const PillarView = dynamic(() => import("../three/PillarView"), { ssr: false });

/** Só monta o 3D quando o card está a ~600px de entrar na tela. */
function useNear(ref: React.RefObject<Element | null>) {
  const [near, setNear] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el || near) return;
    const io = new IntersectionObserver(([e]) => e.isIntersecting && setNear(true), { rootMargin: "600px 0px" });
    io.observe(el);
    return () => io.disconnect();
  }, [ref, near]);
  return near;
}

function PillarCard({ p, onOpen }: { p: Pilar; onOpen: (p: Pilar, el: HTMLElement) => void }) {
  const ref = useRef<HTMLDivElement>(null);
  const gl = use3D((s) => s.gl);
  const ready = use3D((s) => !!s.ready[`card-${p.slug}`]);
  const selected = use3D((s) => s.selected === p.slug);
  const near = useNear(ref);

  const tilt = (e: React.PointerEvent<HTMLElement>) => {
    if (!p.art || e.pointerType !== "mouse") return;
    const r = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - r.left) / r.width) * 2 - 1;
    const y = ((e.clientY - r.top) / r.height) * 2 - 1;
    e.currentTarget.style.setProperty("--rx", `${(-y * 7).toFixed(2)}deg`);
    e.currentTarget.style.setProperty("--ry", `${(x * 9).toFixed(2)}deg`);
  };
  const untilt = (e: React.PointerEvent<HTMLElement>) => {
    e.currentTarget.style.setProperty("--rx", "0deg");
    e.currentTarget.style.setProperty("--ry", "0deg");
  };
  const enter = () => store.set({ hovered: p.slug });
  const leave = () => {
    if (store.get().hovered === p.slug) store.set({ hovered: null });
  };
  // clique no card: seleciona (destaque de 5%); clicar de novo desmarca
  const toggle = () => store.set({ selected: store.get().selected === p.slug ? null : p.slug });

  return (
    <Glass
      as="div"
      ref={ref}
      className={`pillar-card${selected ? " is-selected" : ""}${p.art ? " has-art" : ""}${p.artNoLabel ? " art-nolabel" : ""}`}
      onPointerEnter={(e: React.PointerEvent) => e.pointerType === "mouse" && enter()}
      onPointerMove={tilt}
      onPointerLeave={(e: React.PointerEvent<HTMLElement>) => {
        leave();
        untilt(e);
      }}
    >
      <button
        type="button"
        className="pillar-hit"
        aria-pressed={selected}
        aria-label={`${p.label}: ${p.title}`}
        onClick={toggle}
        onFocus={enter}
        onBlur={leave}
      />
      <span className="media" aria-hidden="true">
        <span className="pillar-glow" style={{ opacity: ready ? 0.45 : 1 }} />
        {!p.art && <svg className="pillar-deco" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet">
          <g fill="none" stroke="currentColor" vectorEffect="non-scaling-stroke">
            <circle cx="50" cy="50" r="36" strokeWidth="1" vectorEffect="non-scaling-stroke" />
            {p.slug === "visibilidade" && <circle cx="50" cy="50" r="42" strokeWidth="1" opacity=".5" vectorEffect="non-scaling-stroke" />}
            <path d="M6 50h8M86 50h8M50 2v10M50 88v10" strokeWidth="1" vectorEffect="non-scaling-stroke" />
          </g>
        </svg>}
        {p.art && <img className="pillar-art" src={p.art} alt="" width={760} height={p.artNoLabel ? 760 : 839} loading="lazy" draggable={false} />}
        {!p.art && gl && near && (
          <span className="gl-view">
            <PillarView url={p.model} slug={p.slug} mode="card" trackRef={ref} />
          </span>
        )}
      </span>
      <span className="pillar-meta" aria-hidden="true">
        <span className="num">{p.n}</span>
        <span className="lbl">{p.label}</span>
      </span>
      <span className="sr-only">{p.desc}</span>
      {/* a seta abre os detalhes em tela cheia (ação que já existia) */}
      <button
        type="button"
        className="round-arrow"
        aria-haspopup="dialog"
        aria-label={`Ver detalhes de ${p.label}`}
        onClick={() => ref.current && onOpen(p, ref.current)}
      >
        <ArrowRight />
      </button>
    </Glass>
  );
}

export function Pilares() {
  const [open, setOpen] = useState<OpenPillar | null>(null);

  const onOpen = useCallback((p: Pilar, el: HTMLElement) => {
    setOpen({ p, rect: el.getBoundingClientRect(), el });
  }, []);

  const onClose = useCallback(() => setOpen(null), []);

  return (
    <section id="pilares" className="band pillars" aria-labelledby="pil-title">
      <div className="wrap">
        <SectionRail index={3} />
        <div className="inner">
          <div className="copy">
            <Reveal as="p" className="eyebrow">
              Os três pilares
            </Reveal>
            <RevealTitle id="pil-title" className="h2" parts={["Três disciplinas. Uma direção."]} delay={0.08} />
            <Reveal as="p" className="lead" delay={0.16}>
              Cada frente resolve uma parte da mesma pergunta: como o seu escritório é visto, encontrado e conduzido.
            </Reveal>
            <Reveal className="actions" delay={0.24}>
              <a className="btn btn--ghost" href="#contato">
                Conheça os pilares <ArrowRight />
              </a>
            </Reveal>
          </div>

          <Carousel className="cards" label="Os três pilares">
            {PILARES.map((p, i) => (
              <Reveal key={p.slug} role="listitem" className="slot" delay={0.12 + i * 0.12}>
                <PillarCard p={p} onOpen={onOpen} />
              </Reveal>
            ))}
          </Carousel>
        </div>
      </div>

      <PillarOverlay open={open} onClose={onClose} PillarView={PillarView} />
    </section>
  );
}
