"use client";

import Image from "next/image";
import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import { Glass } from "../Glass";
import { Reveal, RevealTitle } from "../Reveal";
import { SectionRail } from "../SectionRail";

export function Filosofia() {
  const ref = useRef<HTMLElement>(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  // a imagem anda mais devagar que o texto
  const y = useTransform(scrollYProgress, [0, 1], reduce ? ["0%", "0%"] : ["-7%", "7%"]);

  return (
    <section ref={ref} id="filosofia" className="band philo" aria-labelledby="philo-title">
      <motion.div className="philo-bg" style={{ y }} aria-hidden="true">
        <Image src="/images/filosofia.webp" alt="" fill sizes="100vw" />
      </motion.div>
      <div className="philo-veil" aria-hidden="true" />

      <div className="wrap">
        <SectionRail index={2} />
        <div className="inner">
          <div className="copy">
            <Reveal as="p" className="eyebrow eyebrow--rule">
              Filosofia
            </Reveal>
            <RevealTitle id="philo-title" className="h2" parts={["Excelência também é", { em: "percepção." }]} delay={0.08} />
            <Reveal as="p" className="lead" delay={0.16}>
              Na advocacia, confiança antecede qualquer conversa. A&nbsp;<span translate="no">TRÉVILLE</span> une o rigor de
              uma identidade institucional à precisão de uma operação moderna.
            </Reveal>
          </div>

          <Reveal className="quote-wrap" delay={0.24}>
            <Glass as="blockquote" className="quote">
              <span className="q-mark" aria-hidden="true">
                “
              </span>
              <p>A força de uma marca está naquilo que ela sustenta, não no que promete.”</p>
              <footer>
                — <span translate="no">TRÉVILLE</span>
              </footer>
            </Glass>
          </Reveal>
        </div>
      </div>

      <div className="scroll-mouse" aria-hidden="true">
        <i />
      </div>
    </section>
  );
}
