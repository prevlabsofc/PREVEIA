"use client";

import { useEffect } from "react";
import { pointer } from "./three/store";

/**
 * Camada de interação do site inteiro:
 * - brilho dourado que segue o cursor (ou o dedo) dentro de todo vidro
 * - ímã nos botões (só com mouse)
 * - giroscópio no celular movendo os modelos 3D
 * - liquid glass (refração de verdade) onde o navegador suporta; nos outros, o vidro fosco
 */
export function Interactions() {
  useEffect(() => {
    const root = document.documentElement;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const fine = window.matchMedia("(pointer: fine)").matches;

    // liquid glass: só no Chromium (Chrome, Edge, Android). Safari e Firefox ficam no vidro fosco.
    const brands = (navigator as Navigator & { userAgentData?: { brands: { brand: string }[] } }).userAgentData?.brands;
    const chromium = !!brands?.some((b) => /Chromium/i.test(b.brand));
    if (chromium && !reduce) root.classList.add("lg");

    // --- brilho no vidro
    let lastGlass: HTMLElement | null = null;
    const setGlow = (e: PointerEvent) => {
      const g = (e.target as HTMLElement | null)?.closest?.<HTMLElement>(".glass");
      if (lastGlass && lastGlass !== g) lastGlass.classList.remove("is-lit");
      lastGlass = g ?? null;
      if (!g) return;
      const r = g.getBoundingClientRect();
      g.style.setProperty("--mx", `${e.clientX - r.left}px`);
      g.style.setProperty("--my", `${e.clientY - r.top}px`);
      g.classList.add("is-lit");
    };
    const clearGlow = () => {
      lastGlass?.classList.remove("is-lit");
      lastGlass = null;
    };
    const onDown = (e: PointerEvent) => {
      setGlow(e);
      if (e.pointerType !== "mouse") {
        const g = lastGlass;
        g?.classList.add("is-pressed");
        window.setTimeout(() => {
          g?.classList.remove("is-pressed");
          g?.classList.remove("is-lit");
        }, 520);
      }
    };
    document.addEventListener("pointermove", setGlow, { passive: true });
    document.addEventListener("pointerdown", onDown, { passive: true });
    document.addEventListener("pointerleave", clearGlow);

    // --- ímã nos botões
    let magnet: HTMLElement | null = null;
    const onMagnet = (e: PointerEvent) => {
      if (e.pointerType !== "mouse") return;
      const b = (e.target as HTMLElement | null)?.closest?.<HTMLElement>(".btn, .round-arrow, .menu-btn, .social a");
      if (magnet && magnet !== b) {
        magnet.style.translate = "";
        magnet = null;
      }
      if (!b) return;
      magnet = b;
      const r = b.getBoundingClientRect();
      const dx = e.clientX - (r.left + r.width / 2);
      const dy = e.clientY - (r.top + r.height / 2);
      b.style.translate = `${dx * 0.18}px ${dy * 0.28}px`;
    };
    if (fine && !reduce) document.addEventListener("pointermove", onMagnet, { passive: true });

    // --- giroscópio: inclina os modelos 3D no celular
    const onTilt = (e: DeviceOrientationEvent) => {
      if (e.gamma == null || e.beta == null) return;
      pointer.x = Math.max(-1, Math.min(1, e.gamma / 30));
      pointer.y = Math.max(-1, Math.min(1, -(e.beta - 45) / 30));
      pointer.active = true;
    };
    let tiltOn = false;
    const enableTilt = () => {
      if (tiltOn || reduce || fine) return;
      const DOE = window.DeviceOrientationEvent as unknown as { requestPermission?: () => Promise<string> };
      const start = () => {
        tiltOn = true;
        window.addEventListener("deviceorientation", onTilt, { passive: true });
      };
      if (typeof DOE?.requestPermission === "function") {
        // iPhone: precisa de um toque para pedir permissão
        DOE.requestPermission()
          .then((s) => s === "granted" && start())
          .catch(() => {});
      } else start();
    };
    if (!fine && !reduce) {
      const DOE = window.DeviceOrientationEvent as unknown as { requestPermission?: () => Promise<string> };
      if (typeof DOE?.requestPermission === "function") window.addEventListener("touchend", enableTilt, { once: true });
      else enableTilt();
    }

    return () => {
      document.removeEventListener("pointermove", setGlow);
      document.removeEventListener("pointerdown", onDown);
      document.removeEventListener("pointerleave", clearGlow);
      document.removeEventListener("pointermove", onMagnet);
      window.removeEventListener("deviceorientation", onTilt);
      window.removeEventListener("touchend", enableTilt);
      root.classList.remove("lg");
    };
  }, []);

  // filtro SVG do liquid glass: ruído suave que entorta o que está atrás do vidro
  return (
    <svg width="0" height="0" style={{ position: "absolute" }} aria-hidden="true" focusable="false">
      <filter id="liquid-glass" x="0%" y="0%" width="100%" height="100%" colorInterpolationFilters="sRGB">
        <feTurbulence type="fractalNoise" baseFrequency="0.008 0.012" numOctaves="2" seed="7" result="noise" />
        <feGaussianBlur in="noise" stdDeviation="2" result="soft" />
        <feDisplacementMap in="SourceGraphic" in2="soft" scale="38" xChannelSelector="R" yChannelSelector="G" />
      </filter>
    </svg>
  );
}
