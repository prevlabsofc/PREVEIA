import { createElement, type ComponentProps, type ElementType, type ReactNode } from "react";

type GlassProps<T extends ElementType> = {
  as?: T;
  className?: string;
  children?: ReactNode;
} & Omit<ComponentProps<T>, "as" | "className" | "children">;

/**
 * Todo vidro do site passa por aqui, para que a troca para liquid glass
 * aconteça num lugar só.
 */
export function Glass<T extends ElementType = "div">({ as, className = "", children, ...rest }: GlassProps<T>) {
  return createElement(as ?? "div", { className: `glass ${className}`.trim(), ...rest }, children);
}
