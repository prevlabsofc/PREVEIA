"use client";

import { motion, useScroll, useSpring } from "framer-motion";
import { useRef } from "react";

/** Trilho da esquerda: linha que se enche de dourado conforme a seção avança. */
export function SectionRail({ index, total = 5 }: { index: number; total?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start 0.65", "end 0.65"] });
  const scaleY = useSpring(scrollYProgress, { stiffness: 120, damping: 30, mass: 0.4 });
  const pad = (n: number) => String(n).padStart(2, "0");

  return (
    <div ref={ref} className="rail" aria-hidden="true">
      <span className="track" />
      <motion.span className="fill" style={{ scaleY }} />
      <div className="idx">
        <b>{pad(index)}</b>
        <i />
        {pad(total)}
      </div>
    </div>
  );
}
