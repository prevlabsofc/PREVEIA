"use client";

import Lenis from "lenis";
import { createContext, useContext, useEffect, useRef, useState, type ReactNode } from "react";

type Dir = "down" | "up";
type Ctx = { lenis: Lenis | null; dir: Dir };

const ScrollCtx = createContext<Ctx>({ lenis: null, dir: "down" });
export const useSmoothScroll = () => useContext(ScrollCtx);

/** Direção atual do scroll, lida de forma síncrona (sem re-render). */
export const scrollDir: { current: Dir } = { current: "down" };

export function SmoothScroll({ children }: { children: ReactNode }) {
  const [lenis, setLenis] = useState<Lenis | null>(null);
  const [dir, setDir] = useState<Dir>("down");
  const lastY = useRef(0);

  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    const onScroll = () => {
      const y = window.scrollY;
      if (Math.abs(y - lastY.current) < 2) return;
      const d: Dir = y > lastY.current ? "down" : "up";
      lastY.current = y;
      if (d !== scrollDir.current) {
        scrollDir.current = d;
        setDir(d);
      }
    };
    window.addEventListener("scroll", onScroll, { passive: true });

    let l: Lenis | null = null;
    let raf = 0;
    if (!reduce) {
      l = new Lenis({ duration: 1.1, smoothWheel: true });
      setLenis(l);
      const loop = (t: number) => {
        l?.raf(t);
        raf = requestAnimationFrame(loop);
      };
      raf = requestAnimationFrame(loop);
    }

    // âncoras internas com rolagem suave e compensação do header
    const onClick = (e: MouseEvent) => {
      if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
      const a = (e.target as HTMLElement).closest<HTMLAnchorElement>('a[href^="#"]');
      if (!a) return;
      const id = a.getAttribute("href")!.slice(1);
      const el = id ? document.getElementById(id) : document.body;
      if (!el) return;
      e.preventDefault();
      if (l) l.scrollTo(id === "inicio" ? 0 : el, { offset: -100 });
      else el.scrollIntoView({ behavior: reduce ? "auto" : "smooth" });
      history.replaceState(null, "", `#${id}`);
    };
    document.addEventListener("click", onClick);

    return () => {
      window.removeEventListener("scroll", onScroll);
      document.removeEventListener("click", onClick);
      cancelAnimationFrame(raf);
      l?.destroy();
    };
  }, []);

  return <ScrollCtx.Provider value={{ lenis, dir }}>{children}</ScrollCtx.Provider>;
}
