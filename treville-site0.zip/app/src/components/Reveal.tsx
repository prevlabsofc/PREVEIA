"use client";

import { motion, useInView, useReducedMotion } from "framer-motion";
import { useEffect, useRef, useState, type ElementType, type ReactNode } from "react";
import { scrollDir } from "./SmoothScroll";

const EASE = [0.2, 0.7, 0.2, 1] as const;

type Phase = "rest" | "in" | "out-up" | "out-down";

/**
 * Aparece ao entrar na tela e some ao sair, nos dois sentidos.
 * - Sem JS, tudo fica visível ("rest").
 * - Rolando para baixo: entra subindo e sai por cima.
 * - Rolando para cima: entra descendo e sai por baixo.
 */
function usePhase(ref: React.RefObject<Element | null>, amount = 0.2) {
  const inView = useInView(ref, { amount });
  const [phase, setPhase] = useState<Phase>("rest");
  const mounted = useRef(false);

  useEffect(() => {
    if (!mounted.current) {
      mounted.current = true;
      // primeira leitura: o que está fora da tela já começa escondido, sem animar
      if (!inView) setPhase(scrollDir.current === "down" ? "out-down" : "out-up");
      return;
    }
    if (inView) setPhase("in");
    else setPhase(scrollDir.current === "down" ? "out-up" : "out-down");
  }, [inView]);

  return phase;
}

type RevealProps = {
  as?: ElementType;
  delay?: number;
  className?: string;
  children?: ReactNode;
  amount?: number;
  /** distância da entrada em px */
  y?: number;
} & Record<string, unknown>;

export function Reveal({ as = "div", delay = 0, className, children, amount, y = 28, ...rest }: RevealProps) {
  const ref = useRef<HTMLElement>(null);
  const phase = usePhase(ref, amount);
  const reduce = useReducedMotion();
  const Comp = ((motion as unknown as Record<string, unknown>)[as as string] ?? motion.div) as React.ComponentType<
    Record<string, unknown>
  >;

  const variants = {
    rest: { opacity: 1, y: 0, transition: { duration: 0 } },
    in: { opacity: 1, y: 0, transition: { duration: 0.8, ease: EASE, delay } },
    "out-up": { opacity: 0, y: reduce ? 0 : -14, transition: { duration: 0.4, ease: EASE } },
    "out-down": { opacity: 0, y: reduce ? 0 : y, transition: { duration: 0.4, ease: EASE } },
  };

  return (
    <Comp ref={ref} className={className} initial={false} animate={phase} variants={variants} {...rest}>
      {children}
    </Comp>
  );
}

/** Título que sobe palavra por palavra de trás de uma máscara. */
export function RevealTitle({
  as = "h2",
  className,
  parts,
  delay = 0,
  id,
}: {
  as?: "h1" | "h2" | "h3";
  className?: string;
  parts: Array<string | { em: string }>;
  delay?: number;
  id?: string;
}) {
  const ref = useRef<HTMLHeadingElement>(null);
  const phase = usePhase(ref, 0.3);
  const reduce = useReducedMotion();
  const Tag = as;

  const words: Array<{ w: string; em: boolean }> = [];
  for (const p of parts) {
    const em = typeof p !== "string";
    const text = typeof p === "string" ? p : p.em;
    for (const w of text.split(/\s+/).filter(Boolean)) words.push({ w, em });
  }

  const word = (i: number) => ({
    rest: { y: "0%", opacity: 1, transition: { duration: 0 } },
    in: { y: "0%", opacity: 1, transition: { duration: 0.9, ease: EASE, delay: delay + i * 0.045 } },
    "out-up": { y: reduce ? "0%" : "-40%", opacity: 0, transition: { duration: 0.35, ease: EASE } },
    "out-down": { y: reduce ? "0%" : "105%", opacity: reduce ? 0 : 1, transition: { duration: 0.35, ease: EASE } },
  });

  return (
    <Tag ref={ref} id={id} className={className}>
      {words.map((t, i) => (
        <span key={i}>
          <span className="mask-word">
            <motion.span initial={false} animate={phase} variants={word(i)}>
              {t.em ? <em>{t.w}</em> : t.w}
            </motion.span>
          </span>
          {i < words.length - 1 ? " " : null}
        </span>
      ))}
    </Tag>
  );
}
