"use client";

import Image from "next/image";
import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useState } from "react";
import { Glass } from "./Glass";
import { ArrowRight, CloseIcon, MenuIcon } from "./icons";
import { useSmoothScroll } from "./SmoothScroll";

const NAV = [
  { id: "inicio", label: "Início" },
  { id: "filosofia", label: "Filosofia" },
  { id: "pilares", label: "Pilares" },
  { id: "socios", label: "Sócios" },
  { id: "contato", label: "Contato" },
];

const EASE = [0.2, 0.7, 0.2, 1] as const;

function Brand() {
  return (
    <a className="brand" href="#inicio" aria-label="TRÉVILLE, voltar ao início">
      <Image src="/images/treville-symbol.webp" alt="" width={34} height={29} priority />
      <span translate="no">TRÉVILLE</span>
    </a>
  );
}

export function Header() {
  const [active, setActive] = useState("inicio");
  const [open, setOpen] = useState(false);
  const { lenis } = useSmoothScroll();

  // link ativo conforme a seção no meio da tela
  useEffect(() => {
    // ativo = a última seção cujo topo já passou de 40% da tela (no topo da página, "Início")
    const update = () => {
      const line = window.innerHeight * 0.4;
      let cur = NAV[0].id;
      for (const { id } of NAV) {
        const el = document.getElementById(id);
        if (el && el.getBoundingClientRect().top <= line) cur = id;
      }
      setActive(cur);
    };
    update();
    window.addEventListener("scroll", update, { passive: true });
    window.addEventListener("resize", update);
    return () => {
      window.removeEventListener("scroll", update);
      window.removeEventListener("resize", update);
    };
  }, []);

  // no topo (desktop) a imagem do hero já traz o header; o real aparece ao rolar
  useEffect(() => {
    const el = document.documentElement;
    const f = () => (el.dataset.top = window.scrollY < 90 ? "1" : "0");
    f();
    window.addEventListener("scroll", f, { passive: true });
    return () => window.removeEventListener("scroll", f);
  }, []);

  // menu aberto: trava o scroll e fecha com Esc
  useEffect(() => {
    if (!open) return;
    lenis?.stop();
    document.documentElement.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => {
      lenis?.start();
      document.documentElement.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [open, lenis]);

  return (
    <>
      <header className="site-header">
        <div className="wrap">
          <Glass className="bar intro-drop">
            <Brand />
            <nav className="nav" aria-label="Principal">
              {NAV.map((n) => (
                <a key={n.id} href={`#${n.id}`} aria-current={active === n.id ? "true" : undefined}>
                  {n.label}
                </a>
              ))}
            </nav>
            <a className="btn btn--ghost" href="#contato">
              Iniciar uma conversa <ArrowRight />
            </a>
            <button
              type="button"
              className="menu-btn"
              aria-expanded={open}
              aria-controls="mobile-menu"
              aria-label="Abrir menu"
              onClick={() => setOpen(true)}
            >
              <MenuIcon />
            </button>
          </Glass>
        </div>
      </header>

      <AnimatePresence>
        {open && (
          <motion.div
            id="mobile-menu"
            className="mobile-menu"
            role="dialog"
            aria-modal="true"
            aria-label="Menu"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, transition: { duration: 0.25 } }}
            transition={{ duration: 0.35, ease: EASE }}
          >
            <Glass className="top">
              <Brand />
              <button type="button" className="menu-btn" aria-label="Fechar menu" onClick={() => setOpen(false)} autoFocus>
                <CloseIcon />
              </button>
            </Glass>
            <nav aria-label="Principal">
              {NAV.map((n, i) => (
                <motion.a
                  key={n.id}
                  href={`#${n.id}`}
                  aria-current={active === n.id ? "true" : undefined}
                  onClick={() => setOpen(false)}
                  initial={{ opacity: 0, y: 24 }}
                  animate={{ opacity: 1, y: 0, transition: { delay: 0.08 + i * 0.06, duration: 0.6, ease: EASE } }}
                >
                  {n.label}
                  <small>{String(i + 1).padStart(2, "0")}</small>
                </motion.a>
              ))}
            </nav>
            <motion.div
              className="foot"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0, transition: { delay: 0.45, duration: 0.6, ease: EASE } }}
            >
              <a className="btn btn--gold" href="#contato" onClick={() => setOpen(false)}>
                Iniciar uma conversa <ArrowRight />
              </a>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
