export type Socio = {
  nome: string;
  cargo: string;
  /** Caminho em /public, ex.: "/images/socios/nome.webp". null mostra a silhueta. */
  foto: string | null;
  /** Texto curto que abre ao clicar no card. */
  descricao: string;
  linkedin: string;
};

// Placeholders: troque nome, cargo, foto e LinkedIn de cada sócio.
export const SOCIOS: Socio[] = [
  { nome: "Nome Sobrenome", cargo: "Cargo / Função", foto: null, descricao: "Breve descrição do sócio: formação, experiência e o que conduz na TRÉVILLE.", linkedin: "#" },
  { nome: "Ruth Sena", cargo: "CEO", foto: "/images/socios-ruth.webp", descricao: "CEO da TRÉVILLE. Conduz a estratégia e acompanha cada projeto, do diagnóstico à entrega, sem intermediários.", linkedin: "#" },
  { nome: "Nome Sobrenome", cargo: "Cargo / Função", foto: null, descricao: "Breve descrição do sócio: formação, experiência e o que conduz na TRÉVILLE.", linkedin: "#" },
];
