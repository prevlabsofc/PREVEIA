export type Pilar = {
  slug: "posicionamento" | "visibilidade" | "tecnologia";
  n: string;
  label: string;
  title: string;
  desc: string;
  frase: string;
  model: string;
  /** Arte pronta (imagem com o símbolo e o nome). Sem ela, usa o modelo 3D. */
  art?: string;
  /** A arte não traz o nome dentro; o card mostra o nome como texto. */
  artNoLabel?: boolean;
};

export const PILARES: Pilar[] = [
  {
    slug: "posicionamento",
    n: "01",
    label: "Posicionamento",
    title: "Autoridade & identidade.",
    desc: "Identidade, narrativa e presença que comunicam o nível do seu escritório antes da primeira reunião.",
    frase: "Antes de qualquer palavra, a sua marca já falou.",
    model: "/models/pilar-posicionamento.glb",
    art: "/images/pilar-posicionamento.webp",
  },
  {
    slug: "visibilidade",
    n: "02",
    label: "Visibilidade",
    title: "Presença & descoberta.",
    desc: "Sites, conteúdo e presença digital para ser encontrado por quem decide, no Google e nas IAs.",
    frase: "Quem decide precisa encontrar você primeiro.",
    model: "/models/pilar-visibilidade.glb",
    art: "/images/pilar-visibilidade.webp",
  },
  {
    slug: "tecnologia",
    n: "03",
    label: "Tecnologia",
    title: "Inteligência & operação.",
    desc: "Automação, IA e sistemas internos que dão escala à operação jurídica sem perder o controle.",
    frase: "Escala, sem perder o controle de nenhum detalhe.",
    model: "/models/pilar-tecnologia.glb",
    art: "/images/pilar-tecnologia.webp",
    artNoLabel: true,
  },
];
