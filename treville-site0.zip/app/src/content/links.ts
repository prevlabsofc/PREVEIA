// Troque pelos links reais antes de publicar.
export const LINKS = {
  whatsapp: "https://wa.me/55XXXXXXXXXXX",
  instagram: "https://instagram.com/XXXX",
  linkedin: "https://linkedin.com/company/XXXX",
} as const;
