# TRÉVILLE — site institucional

Next.js 15 · Tailwind 4 · Framer Motion · Lenis · three.js (React Three Fiber + drei)

## Rodar

```bash
npm install
npm run dev      # http://localhost:3000
npm run build && npm start
```

## O que trocar antes de publicar

| O quê | Onde |
|---|---|
| WhatsApp, Instagram, LinkedIn | `src/content/links.ts` |
| Sócios (nome, cargo, foto, LinkedIn) | `src/content/socios.ts` — fotos em `public/images/socios/` (4:5, ~1200×1500) |
| Textos dos pilares e frases do zoom | `src/content/pilares.ts` |
| Domínio (para o og:image) | variável `NEXT_PUBLIC_SITE_URL` na Vercel |

## Como está montado

- **3D do hero e do contato:** um canvas fixo só (`three/GLCanvas.tsx`), com uma janela (`<View>`) para cada cena.
  O logo se apoia na linha do piso da foto `hero-bg.webp` (77% da altura); o reflexo é uma cópia espelhada que só soma luz ao mármore.
- **Pilares:** cada card tem um canvas pequeno próprio (o liquid glass com refração precisa disso) que pausa fora da tela.
  Clique abre o zoom (`PillarOverlay.tsx`), que fecha no X, no Esc e no voltar do celular.
- **Vidro:** toda superfície de vidro passa por `components/Glass.tsx` (classe `.glass`).
  No Chrome, Edge e Android vira liquid glass (filtro SVG `#liquid-glass` em `Interactions.tsx`); no Safari e no Firefox fica o vidro fosco.
- **Interação:** brilho que segue o cursor/dedo no vidro, ímã nos botões, giroscópio no celular (`Interactions.tsx`).
- **Animações:** abertura em CSS puro (roda mesmo sem JS, mais curta na segunda visita da sessão);
  seções aparecem e somem com o scroll nos dois sentidos (`Reveal.tsx`). Tudo respeita "reduzir movimento".
- **Fallback:** sem WebGL, aparece o logo 2D com reflexo no lugar do 3D.

## Modelos

`public/models/*.glb` com compressão Draco; o decodificador fica em `public/draco/` (não depende de CDN).
